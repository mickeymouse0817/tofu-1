import { _100 } from "@raydium-io/raydium-sdk";
import { whitelist } from "./whitelist";

export const config = {
  amountTrade: 0.2,
  slippage: 100,
  cumulativeSol: 5,
  minLUTCount: 5,
  prioityFee: 7,
  retryCount: 50,
  jitoBuyTip: 0.003,
  jitoSellTip: 0.002,
  devBuyMin: 0,
  devBuyMax: 8,
  maxBuyInSlot: 100,
  maxSolAmountBeforBuy: 20,
  cumulativeBlacklist: [],

  initialBuyBlackList: [
    // 1.3, 
    // 2,
    // 2.3
  ],

  initialBuyWhiteList: [],

  maxTxCountInMintBlock: 1,
  tickerBlacklist: [],
  // tickerBlacklist: ['1dontbuy1' , 'dontbuy' ,  '123t3sging' , '1' , 'testing', 'T3sting', 'T3ST','TEN10', 't3sttt' , 'test', 't3ssst' , 'boobism' , 'Chaos'  ],
  // whitelist: ["DRoJmSmpbH4dh48aXL7fJWAettsKysstDvyxXF3GAmGF"],
  NumberAllow: true,
  tp: 15, // Take Profit (%)
  sl: 5, // Stop Loss (%)
  profitTimeout: 180, // seconds
  activityTimeout: 60,
  whitelist: [
    "6MbD8LpEnCzDY9VTXLbUoz1gRY4KgjbWoJCoJVCKffto",
    "Cg8A7DM1B5RuxzkrcjZW3SDtDntUwVSKwoX6oPR4CkYE",
    "5rkYUupj95mHY1jqLao6caeeQ4f9vMeeFvJ36jCZyg7i",
    "7AiqaWb5gcpiKrcJCDRr5Z5h1o6BGDLukcGZR9zY7m1R",
    "HkczTJP1n9QkQEBYMi1J5aY2bZDkooo8SCT6PowkjjLm",
    "4Eju9Hptxq6F51AGmbFd474Uy2rVNrTcfUA9VUgkoAbf",
    "2RVdy5F7EXb6rx4FZpps9DmM5hAbuLb2YKHurj1Gec4r",
    "9dCinTyPXb8qSrMviviSwyDjWwzjxpo1NwHWFQ9w8wxM",

    "PfrJsXsxsyg7MdiWBW8eURHv4cH3vqV5SXb4nPoFuxp",
    "G97dfHgq7yMusphnsSosvoB9TYNQy4vr7bjXtaK3CfrQ",
    "4Z4udzUyuMLTXaxiKpkVyupyo1RYV9dELPjRCUVEh6aL",
    "5v7CXX7c1Ejrhj73bMUeerMH6nrTMLicyMTq79R5ocCX",
    "9AMxrv8YtYaurbvK1mEaEa1z9XssZRnrtiMGsrYhjfyz",
    "3apoqszRdFF8ccgk83L3JFjr53iARDrQkoRyWbgVUjp4",
    "EWGjtVztxuidJRHZu9DrnpddDLiehUP8EzzaoTM9uU6y",
    "7YEcFuMHDhHUZAbZkiTMYAWEhW2CtZpoxweyNTUdVNRU",
    "4s28kyDZ28t2eM7JWyfPyheyhxZLxJnUgsj7xodY4fEW",
    "BQ2mMfJ9JK3bMTtUhxAdsgQ6NdWNUCBNqihVLDvKH3Kv",
    "Eku6ocqxAXwkXPXpg4VW8c7THihCFLo8auevqSppBhyU",
    "BMJyapyy3bRDadpHqL3PC2KvujnPPYdFy7ChuFFzEeuF",
    "7H7V32GN1wUPghF8myYv5P5XhXN8rGEpYr8c8QaJ46xj",
    "BmU2yhpKenfUZy3Neniip6SLLvQACox3vYr5UGbn36vz",
    "AcksZkXPQGy4cdT8qZUSdA6CjB8B49AP1uBce4EPRxJv",
    "GdBHzedjZ5xafSw7Z2SiW8WPiqQRWApxyjKPnvg6qSz9",
    "6XMSs75Z8XcsJiDXczPKArRQURNNjgtxNEBSRqNEAXFw",
    "CWLN9A75AcU351BNhL2jvgQjv1F56SQgQvFQPKbnDB77",
    "mET4pmKRQnHHfrXMD6RhbXPVYxX918Fo2WeXHS6oBYq",
    "3HoPTQE52MFhfF6xJHKGsvRXPwdmqbitEyVFMqVqfK99",
    "64JGcTeHJGyoNdtCh6XSnQJ7iBbXEpL48soHcKzqbxjc",
    "67f9VTm2fcvK6axnmfLesCcMTPatrwFNFhZG9H3txRKD",
    "EuQtohqcynf1rRr1SF3dNEtS1dHbdhXePgFWoYXgaG5a",
    "Hm2tAkW5ot8T5dE6euo4gpvEarVPi22FnTLru45RjVfF",
    "EtH3oGvH7MW7uVDxhAS4fYeC8aKR7Af9nkQ9hoFrRPev",
    "ERB2iTc36GgENCN3HEKHUmbDSoftYRF4NAvvCQJVWNHE",
    "GHkdPfnn8PKKciaBKSTqVyoykLm19rChomUrAV2Pp32M"
    // ""
  ],
  goodMakers: [
    "FXX2JVBQx1THzmJRt26kDAhJDhLg7xZQksbtvhAKmqRC",
    "HR4XkgXq2guDEmSKGis8JDFa6KKhNLoL6vpQjp4DcFmk",
    "4gWjgfchEUNfV4k3XwjFR9V7zXUstccUUHCiQBytSTa5",
    "9i5a36DeheM9uSpbb2j2gBfqv9xTDmbVQgB6qz7EU1im",
    "J2seK1i1SazGQLApNFeyCUv8jDAFySpca61A71LN6hry",
    "C9es1HuZuwWN6Ri4MYUcyzMmtny8buXHnuNsD74NoUPu",
    "7KzbG7PaWMsDWUmE6q3bHFDPWrCv23SFQ6zPEBWk7WhB",
    "2R1SDLWpHb4YXahKWNa9wupN3KKwiDcP3vZmqKeGESgH",
    "2H2uhA6or2awUnGApfifJGsyT15m8za2gUBridXJYpXm",
    "DN4Do7FYAtgWGnAH8BoUD7s4bzwRAbrbk4GWN1eSUppU",
    "8Tq8jLfjHyCKk87AwtBRhFitzeHJjgkANJ5DD44f4iCN",
    "HV7utoLvzKWKP5anY3hQUYvMHFzTzqpZ1SNMbCDJLp3i",
    "FPELzTrRoYR94rsqhiXw9NP5fpGPBVmVR2JfdmwdWL2s",
    "HVgGXKzbKxJ6BAaDiP5cMkLmDCQovo6f2235zkycN9pd",
    "EGmukC1yhdEatE1JixMu5gBch449tWjQytwj9DX2fVwU",
    "7B4bNxMyRRw4DmxSMgBomNQ7yyeJpZqKaTyXBBhezi8b",
    "7axmmf3LXRs3qAUEyVk3dj9vPXQFybf8Ha3KKiEhfxmm",
    "5QDCPGycKEar31Td9LVrJCmz2Eehxdd4UQ5uHrpxthkj",
    "9naUWkRLiyE59PwTbKQ1ru7KbWRWaHcfJjok5RjLFsFB",
    "GCGysRJGiRoVhECRffKPrbvUq3FezDjRgu1b6smNbSA7",
    "7giAspDAZupncZNpBvmE5JYEqVmV1fQ9Bwg7ncgwBxTE",
    "CvJhLYn1YULqj8Z717TqFpKGtkvPH4t12heTJtLmgmxy",
    "6L4xWwkX1E2WQn8pHPyttZnKPJigL8rPaKjFcHsYhEya",
    "BL4L8uG7bkyha3Cv4GzpZR8atgRZNXuLaEq6Z8NgckxS",
    "g7go6r1eesEkesJNASu6xYd76Xz2qsdmR6nZV7QNBSZ",
    "9AEprvsL2rdtRQCqZzbaDwRtVUzqB6gytEuXjB5upSBk"
  ]
}