import { sleep } from "../utils";
import { Metaplex } from "@metaplex-foundation/js";
import { SolTokenMeta } from "../type";
import { PublicKey } from "@solana/web3.js";
import { heliusConnection } from "../endpoint";
import { NATIVE_MINT } from "@solana/spl-token";

export async function solTokenGetMeta(tokenMintAddr: string): Promise<SolTokenMeta|undefined> {
  const metaplex = Metaplex.make(heliusConnection);

  const mintAddress = new PublicKey(tokenMintAddr);

  const metadataAccount = metaplex
    .nfts()
    .pdas()
    .metadata({ mint: mintAddress });

  const metadataAccountInfo = await heliusConnection.getAccountInfo(metadataAccount);

  if (metadataAccountInfo) {
    const token = await metaplex.nfts().findByMint({ mintAddress: mintAddress });
    return {
      name: token.name,
      symbol: token.symbol,
      logo: token.json?.image || ""
    }
  }
  return undefined
}

export async function solTokenGetName(tokenAddr: string): Promise<string[]> {
  if (tokenAddr === NATIVE_MINT.toBase58())
    return ["SOL", "SOL"]
  const meta = await solTokenGetMeta(tokenAddr)
  if (!meta)
    return ["", ""]
  return [meta.name, meta.symbol]
}
