import { ASSOCIATED_TOKEN_PROGRAM_ID, TOKEN_PROGRAM_ID } from "@raydium-io/raydium-sdk";
import { AccountLayout, getAccount, getMint, NATIVE_MINT } from "@solana/spl-token";
import { AccountInfo, PublicKey } from "@solana/web3.js";
import axios from "axios";
import { heliusConnection } from "../endpoint";
import { solAddrPubKey } from "../address";
import { solTokenPrice } from "./price";

export function solTokenGetAccountAddrFromMint(owner: PublicKey, _mint: string|PublicKey) {
  const mint = _mint instanceof PublicKey ? _mint : new PublicKey(_mint)
  const [pda] = PublicKey.findProgramAddressSync([
    owner.toBuffer(),
    TOKEN_PROGRAM_ID.toBuffer(),
    mint.toBuffer()],
    ASSOCIATED_TOKEN_PROGRAM_ID
  );

  return pda
}

export async function getAccountFromMint(mint: PublicKey, wallet: PublicKey) {
  const pda = solTokenGetAccountAddrFromMint(wallet, mint)
  const tokenAccount = await getAccount(heliusConnection, pda);
  return tokenAccount
}

export async function dexscreenerGetTokenInfo(token: string) {
  return await axios
    .get(`https://api.dexscreener.com/latest/dex/tokens/${token}`)
    .then((res: any) => (res.data.pairs === null ? null : res.data.pairs))
    .catch(() => []);
};

export async function solTokenBalance(_mint: PublicKey | string, wallet: PublicKey, decimals: number = 0): Promise<[bigint, number]> {
  try {
    const mint: PublicKey = _mint instanceof PublicKey ? _mint : new PublicKey(_mint)
    const tokenAccount = await getAccountFromMint(mint, wallet)
    const amount = tokenAccount.amount
    let decimal = decimals
    if (!decimal) {
      const mintAccount = await getMint(heliusConnection, mint)
      decimal = mintAccount.decimals
    }
    const balance = Number(amount) / (10 ** decimal)
    return [amount, balance];
  } catch (error) {
    // console.log(`[LIB](SOL-LIB)(TOKEN)(getTokenBalance) error:`, error)
    throw (error)
  }
}

export async function solTokenDecimals(_token: string | PublicKey): Promise<number> {
  const token = solAddrPubKey(_token)
  const mintAccount = await getMint(heliusConnection, token)
  return mintAccount.decimals
}

export async function solTokenAccountExist(wallet:string|PublicKey, mint: string|PublicKey): Promise<boolean> {
  try {
    const tokenAccount = await getAccountFromMint(solAddrPubKey(mint), solAddrPubKey(wallet))
    if (tokenAccount) return true
  } catch (error) {}
  return false
}

export async function solNativePrice() {
  const nativePrice = await (await fetch(`https://price.jup.ag/v4/price?ids=${NATIVE_MINT.toBase58()}`)).json()
  return nativePrice.data[NATIVE_MINT.toBase58()].price
}

export async function solGetMintFromAccount(accountAddr: string): Promise<string|undefined> {
  const accInfo: AccountInfo<Buffer> | null = await heliusConnection.getAccountInfo(new PublicKey(accountAddr))
  if (!accInfo)
    return undefined
  const accountData = AccountLayout.decode(accInfo.data)
  return accountData?.mint?.toBase58()
}

export async function solTokenBalanceInUsd(wallet: string|PublicKey, token: string): Promise<number> {
  const [_, tokenBalance] = await solTokenBalance(token, solAddrPubKey(wallet))
  const tokenPrice = await solTokenPrice(token)
  return tokenPrice * tokenBalance
}