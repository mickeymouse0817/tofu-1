import { createBurnCheckedInstruction, createCloseAccountInstruction, getAssociatedTokenAddress, TokenInstruction } from "@solana/spl-token";
import { Keypair, PublicKey, Transaction, TransactionMessage, VersionedTransaction } from "@solana/web3.js";
import { solTokenBalance, solTokenBalanceInUsd, solTokenDecimals, solTokenGetAccountAddrFromMint } from "./query";
import { heliusConnection } from "../endpoint";
import { TOKEN_PROGRAM_ID } from "@raydium-io/raydium-sdk";
import { solAddrPubKey, solAddrStr } from "../address";
import { solDexscrGetPair } from "../3rdparty";
import { solPoolGetPairByTokenAddr } from "../pool";
import { solTokenPrice } from "./price";

export async function solTokenBurn(signer: Keypair, token: string | PublicKey, amount: number = 0) {
  if (!amount)
    amount = (await solTokenBalance(token, signer.publicKey))[1]
  console.log(`Attempting to burn ${amount} [${token}] tokens from Owner Wallet: ${signer.publicKey.toString()}`);
  // Step 1 - Fetch Associated Token Account Address
  console.log(`Step 1 - Fetch Token Account`);
  const account = await getAssociatedTokenAddress(new PublicKey(token), signer.publicKey);
  console.log(`    ✅ - Associated Token Account Address: ${account.toString()}`);
  // Step 2 - Create Burn Instructions
  const decimals = await solTokenDecimals(token)
  console.log(`Step 2 - Create Burn Instructions`);
  const burnIx = createBurnCheckedInstruction(
    account, // PublicKey of Owner's Associated Token Account
    new PublicKey(token), // Public Key of the Token Mint Address
    signer.publicKey, // Public Key of Owner's Wallet
    amount * (10 ** decimals), // Number of tokens to burn
    decimals // Number of Decimals of the Token Mint
  );
  console.log(`    ✅ - Burn Instruction Created`);

  // Step 3 - Fetch Blockhash
  console.log(`Step 3 - Fetch Blockhash`);
  const { blockhash, lastValidBlockHeight } = await heliusConnection.getLatestBlockhash('finalized');
  console.log(`    ✅ - Latest Blockhash: ${blockhash}`);

  // Step 4 - Assemble Transaction
  console.log(`Step 4 - Assemble Transaction`);
  const messageV0 = new TransactionMessage({
    payerKey: signer.publicKey,
    recentBlockhash: blockhash,
    instructions: [burnIx]
  }).compileToV0Message();
  const transaction = new VersionedTransaction(messageV0);
  transaction.sign([signer]);
  console.log(`    ✅ - Transaction Created and Signed`);

  // Step 5 - Execute & Confirm Transaction 
  console.log(`Step 5 - Execute & Confirm Transaction`);
  const txid = await heliusConnection.sendTransaction(transaction);
  console.log("    ✅ - Transaction sent to network");
  const confirmation = await heliusConnection.confirmTransaction({
    signature: txid,
    blockhash: blockhash,
    lastValidBlockHeight: lastValidBlockHeight
  });
  if (confirmation.value.err) { throw new Error("    ❌ - Transaction not confirmed.") }
  console.log('🔥 SUCCESSFUL BURN!🔥', '\n', `https://explorer.solana.com/tx/${txid}?cluster=mainnet`);
}

export async function solTokenCloseAccount(signer: Keypair, tokenAccount: string | PublicKey) {
  let tx = new Transaction();

  tx.add(
    createCloseAccountInstruction(
      solAddrPubKey(tokenAccount), // fixed
      signer.publicKey, // to be closed token account
      signer.publicKey, // rent's destination
    )
  );

  tx.feePayer = signer.publicKey;
  try {
    const txHash = await heliusConnection.sendTransaction(tx, [signer])
    await heliusConnection.confirmTransaction(txHash);
  } catch (error) {
    console.log(`[LIB](SOL-LIB)(solTokenCloseAccount) error:`, error)
  }
}

export async function solTokenClose(signer: Keypair, tokenAddr: string | PublicKey): Promise<boolean> {
  const wallet = signer.publicKey
  try {
    const [_, balance] = await solTokenBalance(tokenAddr, wallet)
    if (balance) {
      // const value = await solTokenPrice(solAddrStr(tokenAddr)) * balance
      // console.log(`[LIB] closing token which value is ${value}`)
      // if (value > 1) {
      //   console.log(`[LIB](SOL-LIB) You are going to burn token with value over than 1$! skipping...`)
      //   return false
      // }
      const pair = await solPoolGetPairByTokenAddr(tokenAddr)
      if (!pair || pair.liquidity.usd > 500) {
        if (await solTokenBalanceInUsd(signer.publicKey, solAddrStr(tokenAddr)) > 1) {
          console.log(`[LIB](SOL-LIB)(solTokenClose) Liquidity is alive. pair =`, pair)
          return false
        }
      }
      await solTokenBurn(signer, tokenAddr)
    }

    const tokenAccount = solTokenGetAccountAddrFromMint(signer.publicKey, tokenAddr)
    console.log(`[LIB](SOL0LIB) Closing token `, tokenAddr)
    await solTokenCloseAccount(signer, tokenAccount)
  } catch (error) {
    console.log(`[LIB](SOL-LIB)(solTokenClose) Error closing token.`)
    return false
  }
  return true
}