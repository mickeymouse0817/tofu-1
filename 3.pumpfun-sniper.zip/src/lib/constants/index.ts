import dotenv from "dotenv"
import { solWalletImport } from "../wallet"

dotenv.config()

export const SOL_ACCOUNT_RENT_FEE = 0.00203928
export const PRIVATE_KEY = process.env.PRIVATE_KEY
export const RAYDIUM_AUTHORITY_V4 = "5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1"
export const PUMPFUN = "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P"
export const JUPITER = "JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4"
export const BLOXROUTER = "HWEoBxYs7ssKuudEjzjmpfJVX7Dvi7wescFsVx2L5yoY"

export const LOOKUP_TABLE_ADDRS: string[] = [
  "DFFZshbpQHpU7pQTqepG29CFDuU9G6bMP5kNcaYUYRPY"
  // "4ccgPnZAKdmEwZJLrSvjUjqPCeSLMxM6GtqP7UnBrUn3" // --
]