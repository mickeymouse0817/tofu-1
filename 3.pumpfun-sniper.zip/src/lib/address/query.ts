import { PublicKey } from "@solana/web3.js";
import { solAddrPubKey } from './index';
import { heliusConnection } from "../endpoint";

export async function solAccountGetOwner(_addr: string|PublicKey): Promise<any> {
  const addr = solAddrPubKey(_addr)
  const accInfo = await heliusConnection.getParsedAccountInfo(addr, 'finalized')
  const data:any = accInfo.value?.data
  if (!data)
    return undefined
  return data.parsed.info.owner
}