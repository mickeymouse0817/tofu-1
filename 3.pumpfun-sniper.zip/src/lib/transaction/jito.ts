import { SearcherClient, searcherClient } from "jito-ts/dist/sdk/block-engine/searcher";
import { Bundle } from "jito-ts/dist/sdk/block-engine/types";
import { ComputeBudgetProgram, Connection, Keypair, LAMPORTS_PER_SOL, PublicKey, SystemProgram, Transaction, TransactionInstruction, TransactionMessage, VersionedMessage, VersionedTransaction } from "@solana/web3.js";
import axios from "axios";
import base58 from "bs58";
import dotenv from 'dotenv';
import { sleep } from "../utils";

dotenv.config({
  path: '.env',
});

const blockEngineUrl = process.env.BLOCK_ENGINE_URL as string;
const JITO_TIMEOUT = 150000;

const jitotipAccounts = [
  '96gYZGLnJYVFmbjzopPSU6QiEV5fGqZNyN9nmNhvrZU5', // Jitotip 1
  'HFqU5x63VTqvQss8hp11i4wVV8bD44PvwucfZ2bU7gRe', // Jitotip 2
  'Cw8CFyM9FkoMi7K7Crf6HNQqf4uEMzpKw6QNghXLvLkY', // Jitotip 3
  'ADaUMid9yfUytqMBgopwjb2DTLSokTSzL1zt6iGPaS49', // Jitotip 4
  'DfXygSm4jCyNCybVYYK6DwvWqjKee8pbDmJGcLWNDXjh', // Jitotip 5
  'ADuUkR4vqLUMWXxW9gh6D6L8pMSawimctcNZ5pGwDcEt', // Jitotip 6
  'DttWaMuVvTiduZRnguLF7jNxTgiMBZ1hyAumKUiL2KRL', // Jitotip 7
  '3AVi9Tg9Uo68tJfuvoKvqKNWKkC5wPdSSdeBnizKZ6jT', // Jitotip 8
]

export function makeJitoTipInstruction(wallet: PublicKey, tip: number): TransactionInstruction {
  const jitoIdx = Math.floor(Math.random() * 7)
  const tipAccount = new PublicKey(jitotipAccounts[jitoIdx]);
  const tipIx = SystemProgram.transfer({
    fromPubkey: wallet,
    toPubkey: tipAccount,
    lamports: Math.max(Math.floor(tip * LAMPORTS_PER_SOL), 5001),
  })
  return tipIx
}

export async function onBundleResult(c: SearcherClient): Promise<boolean> {
  let first = 0;
  let isResolved = false;

  return new Promise((resolve) => {
    // Set a timeout to reject the promise if no bundle is accepted within 5 seconds
    setTimeout(() => {
      // console.log(`[JITO] bundle timeout!`)
      resolve(true);
      isResolved = true
    }, 5000);

    c.onBundleResult((result: any) => {
        if (isResolved) return true;
        // clearTimeout(timeout); // Clear the timeout if a bundle is accepted
        const bundleId = result.bundleId;
        const isAccepted = result.accepted;
        const isRejected = result.rejected;
        
        if (isAccepted) {
          console.log(
            "bundle accepted, ID:",
            result.bundleId,
            " Slot: ",
            result.accepted?.slot
          );
          first += 1;
          isResolved = true;
          resolve(true); // Resolve with 'first' when a bundle is accepted
        }
        if (isRejected) {
          // console.log("bundle is Rejected:", result);
          if (result?.rejected?.simulationFailure)
            resolve(false)
          else if (result?.rejected?.droppedBundle)
            resolve(true)
          // Do not resolve or reject the promise here
        }
      },
      (e) => {
        // console.error(e);
        // Do not reject the promise here
      }
    );
  });
};

export async function solJitoSend(
  bundleTransactionLimit: number,
  tx: VersionedTransaction,
  signer: Keypair,
  tip: number,
) {
  const search = searcherClient(blockEngineUrl);
  const jitoIdx = Math.floor(Math.random() * 7)
  const tipAccount = new PublicKey(jitotipAccounts[jitoIdx]);
  const bund = new Bundle([], bundleTransactionLimit + 1);

  const tipIx = SystemProgram.transfer({
    fromPubkey: signer.publicKey,
    toPubkey: tipAccount,
    lamports: Math.max(Math.floor(tip * LAMPORTS_PER_SOL), 5001),
  })
  const jitoMessage = new TransactionMessage({
    payerKey: signer.publicKey,
    recentBlockhash: tx.message.recentBlockhash,
    instructions: [tipIx]
  }).compileToV0Message()
  const jitoTr = new VersionedTransaction(jitoMessage)
  jitoTr.sign([signer])
  tx.sign([signer])
  const buildBundle = bund.addTransactions(tx, jitoTr);

  try {
    await search.sendBundle(buildBundle as Bundle);
    const bundleResult = await onBundleResult(search)
    // console.log(`[JITO] bundleResult :`, bundleResult)
    return base58.encode(tx.signatures[0])
  } catch (e) {
    console.log('error sending bundle:\n', e);
    return undefined
  }
}

export async function jitoSendBunleByApi(transactions: VersionedTransaction[]) {
  try {
    if (transactions.length === 0)
      return;

    let bundleIds: any[] = [];
    const rawTransactions = transactions.map(item => base58.encode(item.serialize()));
    const { data } = await axios.post(`https://${process.env.BLOCK_ENGINE_URL}/api/v1/bundles`,
      {
        jsonrpc: "2.0",
        id: 1,
        method: "sendBundle",
        params: [
          rawTransactions
        ],
      },
      {
        headers: {
          "Content-Type": "application/json",
        },
      }
    );
    if (data) {
      console.log(data);
      bundleIds = [
        ...bundleIds,
        data.result,
      ];
    }

    console.log("Checking bundle's status...", bundleIds);
    const sentTime = Date.now();
    while (Date.now() - sentTime < JITO_TIMEOUT) {
      try {
        const { data } = await axios.post(`https://${process.env.BLOCK_ENGINE_URL}/api/v1/bundles`,
          {
            jsonrpc: "2.0",
            id: 1,
            method: "getBundleStatuses",
            params: [
              bundleIds
            ],
          },
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        if (data) {
          const bundleStatuses = data.result.value;
          // console.log("Bundle Statuses:", bundleStatuses);
          let success = true;
          for (let i = 0; i < bundleIds.length; i++) {
            const matched = bundleStatuses.find((item: any) => item && item.bundle_id === bundleIds[i]);
            if (!matched || matched.confirmation_status !== "finalized") {
              success = false;
              break;
            }
          }

          if (success)
            return true;
        }
      }
      catch (err: any) {
        // console.error(`[JITO] error:: `, err.toString());
      }

      await sleep(1000);
    }
  }
  catch (err: any) {
    console.log(err);
  }
  return false;
}

export async function solJitoSendByApi(
  tx: VersionedTransaction,
  signer: Keypair,
  tip: number,
): Promise<string | undefined> {

  const jitoIdx = Math.floor(Math.random() * 7)
  const tipAccount = new PublicKey(jitotipAccounts[jitoIdx]);
  const tipIx = SystemProgram.transfer({
    fromPubkey: signer.publicKey,
    toPubkey: tipAccount,
    lamports: Math.max(Math.floor(tip * LAMPORTS_PER_SOL), 5001),
  })

  const jitoMessage = new TransactionMessage({
    payerKey: signer.publicKey,
    recentBlockhash: tx.message.recentBlockhash,
    instructions: [tipIx]
  }).compileToV0Message()
  const jitoTr = new VersionedTransaction(jitoMessage)
  jitoTr.sign([signer])
  tx.sign([signer])
  const success = await jitoSendBunleByApi([tx, jitoTr])
  if (success === true)
    return base58.encode(tx.signatures[0])
  return undefined
}