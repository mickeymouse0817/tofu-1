import { PublicKey } from "@metaplex-foundation/js";
import { heliusConnection } from "../endpoint";
import { sleep } from "../utils";

export async function solBlockTimeGet(slot: number, loop: boolean = false): Promise<number | null> {
  do {
    try {
      let timestamp = await heliusConnection.getBlockTime(slot)
      if (timestamp) 
        return timestamp *= 1000
    } catch (error) {}
    await sleep(100)
  } while (loop);
  return 0
}

export async function solGetPriorityFee(): Promise<number> {
  const feesResp = await heliusConnection.getRecentPrioritizationFees({
    lockedWritableAccounts: [new PublicKey("JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4")]
  })
  const prioFees = feesResp.filter(fee => fee.prioritizationFee !== 0)
  if (prioFees.length === 0)
    return 0
  // console.log(prioFees)
  let sumFee = 0
  prioFees.forEach((fee) => sumFee += fee.prioritizationFee)
  prioFees.sort((a, b) => a.prioritizationFee < b.prioritizationFee ? 1 : -1)
  // console.log(`[LIB](SOL-LIB) maxFee = ${prioFees[0].prioritizationFee}, minFee = ${prioFees[prioFees.length-1].prioritizationFee}`)
  return Math.ceil(sumFee / prioFees.length)
}

export async function solBlockGetSlotForTimestamp(timestamp: number): Promise<number> {
  if (!timestamp)
    return 0

  const curSlot = await heliusConnection.getSlot("finalized")
  const curChainTimestamp = await solBlockTimeGet(curSlot, true)
  // console.log(`[LIB] timestamp = ${timestamp}, chainTimestamp = ${curChainTimestamp}`)
  if (!curChainTimestamp)
    return 0

  if (curChainTimestamp < timestamp)
    return curSlot

  let expectingSoltCount = Math.floor((curChainTimestamp - timestamp) / 500)
  let slot = curSlot - expectingSoltCount
  // console.log(`[LIB] expecting slot =`, slot)
  let chainTime = await solBlockTimeGet(slot, true)
  if (!chainTime)
    return 0

  // console.log(`[LIB] expectingChainTime = ${curChainTimestamp}, timestamp = ${timestamp}`)
  // if blocktime is less than timestamp
  while (chainTime < timestamp) {
    expectingSoltCount = Math.floor((timestamp - chainTime) / 500)
    if (!expectingSoltCount)
      return slot
    slot += expectingSoltCount
    chainTime = await solBlockTimeGet(slot, true)
    if (!chainTime)
      return 0
  }

  // if blocktime is greater than timestamp
  while (chainTime > timestamp) {
    expectingSoltCount = Math.floor((chainTime - timestamp) / 500)
    if (!expectingSoltCount)
      return slot
    slot -= expectingSoltCount
    chainTime = await solBlockTimeGet(slot, true)
    if (!chainTime)
      return 0
  }

  return slot
}