import { Keypair, LAMPORTS_PER_SOL, PublicKey, SystemProgram, Transaction } from "@solana/web3.js";
import base58 from "bs58";
import { SolWallet } from "../type";
import { heliusConnection } from "../endpoint";
import { BigNumberish, SPL_ACCOUNT_LAYOUT, TOKEN_PROGRAM_ID } from "@raydium-io/raydium-sdk";
import { solAddrPubKey, solKeyPair } from "../address";
import { AccountLayout, NATIVE_MINT } from "@solana/spl-token";
import { solTokenBalance } from "../token";
import { solTokenClose } from "../token/action";
import { solTrCreateAndSendV0Tx } from "../transaction";

export async function solWalletCreate(): Promise<SolWallet> {
  const keypair = Keypair.generate();
  return {
    pubKey: keypair.publicKey,
    privKey: base58.encode(keypair.secretKey)
  }
}

export function solWalletImport(privKey: string): Keypair | undefined {
  try {
    const keypair = Keypair.fromSecretKey(base58.decode(privKey))
    return keypair
  } catch (error) {
    console.log(`[LIB](SOL-LIB)(solWalletImport) error:`, error)
    return undefined
  }
}

export function solWalletKeyPair(wallet: string | Keypair): Keypair | undefined {
  if (wallet instanceof Keypair)
    return wallet
  return solWalletImport(wallet)
}

export async function solWalletGetBalance(
  _pubKey: string | PublicKey, 
  withWrapped: boolean = false,
  isRaw: boolean = false
): Promise<number> {
  let pubKey: PublicKey
  if (typeof _pubKey === "string")
    pubKey = new PublicKey(_pubKey)
  else
    pubKey = _pubKey

  let balance = (await heliusConnection.getBalance(new PublicKey(pubKey))) / LAMPORTS_PER_SOL
  if (withWrapped) {
    try {
      const [_, wBalance] = await solTokenBalance(NATIVE_MINT, pubKey)
      balance += wBalance
    } catch (error) { }
  }
  return balance;
}

export async function solWalletGetTokenAccounts(_wallet: string | PublicKey | Keypair): Promise<any[]> {
  const wallet = solAddrPubKey(_wallet)
  const walletTokenAccount = await heliusConnection.getTokenAccountsByOwner(wallet, {
    programId: TOKEN_PROGRAM_ID,
  })

  const userTokenAccounts = walletTokenAccount.value.map((i) => ({
    pubkey: i.pubkey,
    programId: i.account.owner,
    accountInfo: SPL_ACCOUNT_LAYOUT.decode(i.account.data)
  }))
  return userTokenAccounts
}

export async function solWalletGetTokenList(wallet: PublicKey): Promise<string[]> {
  const MAX_QUERY_NUM = 100
  const walletTokenAccount = await heliusConnection.getTokenAccountsByOwner(wallet, {
    programId: TOKEN_PROGRAM_ID,
  })
  const tokenAccounts = walletTokenAccount.value.map((account) => account.pubkey)
  let tokenList: any[] = []
  for (let i = 0; i < tokenAccounts.length; i += MAX_QUERY_NUM) {
    const qnum = Math.min(MAX_QUERY_NUM, tokenAccounts.length - i)
    const tlist = await heliusConnection.getMultipleAccountsInfo(tokenAccounts.slice(i, i + qnum))
    tokenList = [...tokenList, ...tlist]
  }
  return tokenList.map((t) => AccountLayout.decode(t.data).mint.toString())
}

export async function solWalletCloseAllTokenAccount(_wallet: string | Keypair) {
  const signer = solKeyPair(_wallet)
  if (!signer)
    return
  const tokenAccounts = await solWalletGetTokenAccounts(signer.publicKey)
  let closedCnt = 0
  for (const t of tokenAccounts) {
    const clAcc = {
      account: t.pubkey.toBase58(),
      mint: t.accountInfo.mint.toBase58(),
      amount: Number(t.accountInfo.amount)
    }
    console.log(`${clAcc.mint} : ${clAcc.amount}`)
    if (await solTokenClose(signer, clAcc.mint) === true) {
      closedCnt++
    }
  }
}

export async function sollWalletSendBalance(_sender: string | Keypair, _recipient: string | PublicKey, amount: BigNumberish) {
  const sender = solKeyPair(_sender)
  const recipient = solAddrPubKey(_recipient)
  if (!sender)
    return

  const trInstr = SystemProgram.transfer({
    fromPubkey: sender.publicKey,
    toPubkey: recipient,
    lamports: amount
  })
  await solTrCreateAndSendV0Tx(sender, [trInstr])
}

export async function solWalletWithdrawAll(_wallet: string | Keypair, dest: string) {
  const wallet = solKeyPair(_wallet)
  if (!wallet)
    return
  console.log(`[LIB] withdrawing from ${wallet.publicKey} ...`)
  const transactionFee = 5000 / LAMPORTS_PER_SOL;
  const walletBalance = await solWalletGetBalance(wallet.publicKey) 
  if (walletBalance === 0) {
    console.log(`[LIB] zero balance. skipping...`)
    return
  }
  const amountToSend = (walletBalance - transactionFee)
  console.log(`[LIB] withdrawing ${walletBalance}/${amountToSend} sol ...`)
  await sollWalletSendBalance(wallet, dest, Math.floor(amountToSend * LAMPORTS_PER_SOL))
}

export async function solWalletListWithdraw(privkeyList: string[], dest: string) {
  for(const privKey of privkeyList) {
    const sender = solKeyPair(privKey)
    if (!sender)
      continue
    await solWalletCloseAllTokenAccount(sender)
    await solWalletWithdrawAll(sender, dest)
  }
  console.log(`[LIB] successfully withdraw from ${privkeyList.length} wallets.`)
}
