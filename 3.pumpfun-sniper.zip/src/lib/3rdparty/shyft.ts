// import { gql, GraphQLClient } from "graphql-request";

const SHYFT_API_KEY = process.env.SHYFT_API_KEY

export async function solShyftGetPoolByMint(mintAddress: string) {
  //get a fluxbeam Pool details based on a particular token address
  const operationsDoc = `
      query MyQuery {
        Fluxbeam_TokenSwap(
          where: {_or: [{_or: {mintB: {_eq: ${JSON.stringify(mintAddress)}}}},{_or: {mintA: {_eq: ${JSON.stringify(mintAddress)}}}}]}
        ) {
          tokenPool
          mintB
          mintA
          pubkey
          curveType
        }
      }
      `; //graphQl query
  const result = await fetch(
    `https://programs.shyft.to/v0/graphql/accounts?api_key=${SHYFT_API_KEY}&network=mainnet-beta`, //SHYFT's GQL endpoint
    {
      method: "POST",
      body: JSON.stringify({
        query: operationsDoc,
        variables: {},
        operationName: "MyQuery",
      }),
    },
  );

  const { errors, data } = await result.json();

  console.dir(data, { depth: null });
}

// const endpoint = `https://programs.shyft.to/v0/graphql/?api_key=YOUR-KEY`;

// const graphQLClient = new GraphQLClient(endpoint, {
//   method: `POST`,
//   jsonSerializer: {
//     parse: JSON.parse,
//     stringify: JSON.stringify,
//   },
// });

// export async function solShyftQueryLpByToken(token: string) {
//   // Get all proposalsV2 accounts
//   const query = gql`
//     query MyQuery($where: Raydium_LiquidityPoolv4_bool_exp) {
//   Raydium_LiquidityPoolv4(
//     where: $where
//   ) {
//     _updatedAt
//     amountWaveRatio
//     baseDecimal
//     baseLotSize
//     baseMint
//     baseNeedTakePnl
//     baseTotalPnl
//     baseVault
//     depth
//     lpMint
//     lpReserve
//     lpVault
//     marketId
//     marketProgramId
//     maxOrder
//     maxPriceMultiplier
//     minPriceMultiplier
//     minSeparateDenominator
//     minSeparateNumerator
//     minSize
//     nonce
//     openOrders
//     orderbookToInitTime
//     owner
//     pnlDenominator
//     pnlNumerator
//     poolOpenTime
//     punishCoinAmount
//     punishPcAmount
//     quoteDecimal
//     quoteLotSize
//     quoteMint
//     quoteNeedTakePnl
//     quoteTotalPnl
//     quoteVault
//     resetFlag
//     state
//     status
//     swapBase2QuoteFee
//     swapBaseInAmount
//     swapBaseOutAmount
//     swapFeeDenominator
//     swapFeeNumerator
//     swapQuote2BaseFee
//     swapQuoteInAmount
//     swapQuoteOutAmount
//     systemDecimalValue
//     targetOrders
//     tradeFeeDenominator
//     tradeFeeNumerator
//     volMaxCutRatio
//     withdrawQueue
//     pubkey
//   }
// }`;

//   //Tokens can be either baseMint or quoteMint, so we will check for both with an _or operator
//   const variables = {
//     where: {
//       _or: [
//         { baseMint: { _eq: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263" } },
//         { quoteMint: { _eq: "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263" } },
//       ]
//     }
//   };

//   graphQLClient.request(query, variables).then(console.log);
// }

