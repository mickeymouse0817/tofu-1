import Client, { CommitmentLevel, SubscribeRequest } from "@triton-one/yellowstone-grpc";
import { getCurrentTimestamp, sleep } from "../utils";
import { solBlockTimeGet } from "../block";

export async function reportDetectionTime(description: string, block: number, others?:any) {
  const curTime = getCurrentTimestamp()
  const blockTime = await solBlockTimeGet(block, true)
  if (!blockTime)
    return
  const detectionTime = curTime - blockTime
  console.log(`[${description}] Detection time : ${detectionTime} ms. ${others ? `(initialBuy: ${others})` : ""}`)
}

let grpcClient: Client|null = null
let isSubscribed = false;
// ref : https://github.com/raydium-io/raydium-sdk-V1-demo/blob/master/src/subNewAmmPool.ts
export async function solGrpcStart(monitorAddrs: string[], callback:any, param:any = undefined) {

  while (!grpcClient) {
    try {
      // Open connection.
      grpcClient = new Client(
        process.env.GRPC_URL || "",
        process.env.GRPC_ACCESS_TOKEN,
        {
          "grpc.max_receive_message_length": 256 * 1024 * 1024, // 64MiB
        }
      );
    } catch (error) {
      console.log('Geyser Client Get Error:', error);
      grpcClient = null;
      await sleep(3000)
    }
  }

  while (isSubscribed === false) {
    try {
      const stream = await grpcClient.subscribe();
      // console.log(`[SOL-LIB](grpc) stream =`, stream)
      const request: SubscribeRequest = {
        slots: {},
        accounts: {},
        transactions: {
          transactionsSubKey: {
            accountInclude: monitorAddrs,
            accountExclude: [],
            accountRequired: []
          }
        },
        transactionsStatus: {},
        blocks: {},
        blocksMeta: {},
        accountsDataSlice: [],
        entry: {},
        commitment: CommitmentLevel.PROCESSED
      }

      const streamSubscribe = new Promise((resolve: any, reject: any) => {
        stream.write(request, (err: any) => {
          if (err === null || err === undefined) {
            resolve();
          } else {
            reject(err);
          }
        });
      });

      // Create `error` / `end` handler
      const streamClosed = new Promise((resolve: any, reject: any) => {
        stream.on("error", async (error) => {
          reject(error);
          stream.end();
        });
        stream.on("end", () => {
          resolve();
        });
        stream.on("close", async () => {
          resolve();
          isSubscribed = false;
        });

      });

      // Handle updates
      stream.on("data", async (data) => {
        if (callback)
          if (data.filters.includes('transactionsSubKey') !== true)
            return
        const info: any = data.transaction
        if (info.transaction.meta.err)
          return
          await callback(info, param)
      })

      isSubscribed = true;
      await streamSubscribe;
      await streamClosed;
    } catch (error) {
      console.log(`[SOL-LIB] grpcStart:: error=`, error)
    }
  }
}