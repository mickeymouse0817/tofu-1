import axios from "axios"
import { SolPairInfo } from "../type";
import { Liquidity } from '@raydium-io/raydium-sdk';
import { PublicKey } from "@metaplex-foundation/js";

export async function solDexscrGetPair(_tokenAddress: string | PublicKey): Promise<SolPairInfo | undefined> {
  const tokenAddress = (_tokenAddress instanceof PublicKey) ? _tokenAddress.toBase58() : _tokenAddress
  const url = `https://api.dexscreener.com/latest/dex/tokens/${tokenAddress}`;
  try {
    const response = await axios.get(url);
    const data = response.data;
    // console.log(`[LIB](SOL-LIB)(3RD-PARY)(dexscreener)(solDexscrGetPairAddr) data: `, JSON.stringify(data))
    const pair = data.pairs[0]
    return {
      pair: pair.pairAddress,
      baseToken: pair.baseToken.address,
      quoteToken: pair.quoteToken.address,
      liquidity: pair.liquidity,
      createdAt: pair.pairCreatedAt
    }
  } catch (error) {
    // console.log(`[LIB](SOL-LIB)(3RD-PARY)(dexscreener)(solDexscrGetPairAddr) error: `, error)
    return undefined;
  }
}