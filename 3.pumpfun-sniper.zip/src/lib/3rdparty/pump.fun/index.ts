import { Idl, Program } from "@coral-xyz/anchor";
import axios from "axios";
import idl from "./idl/pumpfun.json"
import * as anchor from "@coral-xyz/anchor"
import { PF_ACCOUNT, PF_ASSOC_TOKEN_ACC_PROG, PF_FEE_RECIPIENT, PF_GLOBAL, PF_PROGRAM_ID, PRIORITY_FEE_BASE, RENT } from "./constants";
import { Keypair, LAMPORTS_PER_SOL, PublicKey, TransactionInstruction, TransactionMessage, VersionedTransaction, ComputeBudgetProgram } from '@solana/web3.js';
import { solAddrPubKey } from "../../address";
import { ASSOCIATED_TOKEN_PROGRAM_ID, createAssociatedTokenAccountInstruction, getAssociatedTokenAddress } from "@solana/spl-token";
import { SYSTEM_PROGRAM_ID, TOKEN_PROGRAM_ID } from "@raydium-io/raydium-sdk";
import { solWalletKeyPair } from "../../wallet";
import { heliusConnection } from "../../endpoint";
import bs58 from 'bs58';
import { solJitoSend, solJitoSendByApi } from "../../transaction/jito";
import { solTrSendVersionedTransaction } from "../../transaction";
import { bufferFromUInt64, bytesToUInt64 } from "../../utils/buffer";
import { solCheckTr } from "solana-tr-check";
export * from "./constants"

export async function pfGetTokenDataByApi(mintStr: string, logger: any = console): Promise<any> {
  try {
    const url = `https://frontend-api.pump.fun/coins/${mintStr}`;
    const response = await axios.get(url);
    if (response.status === 200) {
      return response.data;
    } else {
      // logger.error('Failed to retrieve coin data:', response.status);
      return undefined;
    }
  } catch (error: any) {
    // logger.error('Error fetching coin data:', error.code);
    return undefined;
  }
}

function pfGetBondingCurve(_token: string | PublicKey): PublicKey {
  const token = solAddrPubKey(_token)
  const [pda, _] = PublicKey.findProgramAddressSync(
    [Buffer.from('bonding-curve'), token.toBuffer()],
    PF_PROGRAM_ID)
  return pda
}

async function pfGetBondingCurveAta(_token: string | PublicKey, _bondingCurve: string | PublicKey): Promise<PublicKey> {
  const token = solAddrPubKey(_token)
  const bondingCurve = solAddrPubKey(_bondingCurve)
  const ata = await getAssociatedTokenAddress(
    token,
    bondingCurve,
    true,
    TOKEN_PROGRAM_ID,
    ASSOCIATED_TOKEN_PROGRAM_ID
  );
  return ata
}

export async function pfGetTokenDataByWeb3(token: string, logger: any = console): Promise<any> {
  const dummyWallet = {
    publicKey: PublicKey.default,
    signAllTransactions: async (txs: any) => txs,
    signTransaction: async (tx: any) => tx,
  };

  const bondingCurveProgram = new Program(
    idl as Idl,
    PF_PROGRAM_ID,
    new anchor.AnchorProvider(
      heliusConnection,
      dummyWallet,
      anchor.AnchorProvider.defaultOptions())
  )

  try {
    const bonding_curve = pfGetBondingCurve(token)
    const bondingCurveData = await bondingCurveProgram.account.bondingCurve.fetch(bonding_curve)
    const virtual_token_reserves = (bondingCurveData.virtualTokenReserves as any).toNumber();
    const virtual_sol_reserves = (bondingCurveData.virtualSolReserves as any).toNumber();
    const associated_bonding_curve = await pfGetBondingCurveAta(token, bonding_curve)
    return {
      bonding_curve,
      virtual_token_reserves,
      virtual_sol_reserves,
      associated_bonding_curve
    }
  } catch (error) {
    try {
      const tokenData = await pfGetTokenDataByApi(token) 
      if (!tokenData)
        return undefined
      return {
        bonding_curve: tokenData.bonding_curve,
        virtual_token_reserves: tokenData.virtual_token_reserves,
        virtual_sol_reserves: tokenData.virtual_sol_reserves,
        associated_bonding_curve: tokenData.associated_bonding_curve
      }
    } catch (error) {
      return undefined 
    }
  }
}

// ref : https://github.com/degenfrends/solana-pumpfun-trader/blob/main/src/index.ts
export async function solPFGetBuyInstruction(
  _owner: string | PublicKey,
  tokenAddress: string,
  amount: number,
  slippage: number = 25
): Promise<TransactionInstruction[] | undefined> {
  const owner = solAddrPubKey(_owner)

  const coinData = await pfGetTokenDataByWeb3(tokenAddress);
  if (!coinData) {
    console.error('Failed to retrieve coin data...');
    return undefined;
  }

  const token = new PublicKey(tokenAddress);

  const tokenAccountAddress = await getAssociatedTokenAddress(token, owner, false);
  const tokenAccountInfo = await heliusConnection.getAccountInfo(tokenAccountAddress);

  const instructions: TransactionInstruction[] = []
  let tokenAccount: PublicKey;
  if (!tokenAccountInfo) {
    instructions.push(
      createAssociatedTokenAccountInstruction(owner, tokenAccountAddress, owner, token)
    );
    tokenAccount = tokenAccountAddress;
  } else {
    tokenAccount = tokenAccountAddress;
  }

  const solInLamports = amount * LAMPORTS_PER_SOL;
  const tokenOut = Math.floor((solInLamports * coinData['virtual_token_reserves']) / coinData['virtual_sol_reserves']);

  const amountWithSlippage = amount * (1 + (slippage / 100));
  const maxSolCost = Math.floor(amountWithSlippage * LAMPORTS_PER_SOL);
  const ASSOCIATED_USER = tokenAccount;
  const USER = owner;
  const BONDING_CURVE = new PublicKey(coinData['bonding_curve']);
  const ASSOCIATED_BONDING_CURVE = new PublicKey(coinData['associated_bonding_curve']);

  const keys = [
    { pubkey: PF_GLOBAL, isSigner: false, isWritable: false },
    { pubkey: PF_FEE_RECIPIENT, isSigner: false, isWritable: true },
    { pubkey: token, isSigner: false, isWritable: false },
    { pubkey: BONDING_CURVE, isSigner: false, isWritable: true },
    { pubkey: ASSOCIATED_BONDING_CURVE, isSigner: false, isWritable: true },
    { pubkey: ASSOCIATED_USER, isSigner: false, isWritable: true },
    { pubkey: USER, isSigner: false, isWritable: true },
    { pubkey: SYSTEM_PROGRAM_ID, isSigner: false, isWritable: false },
    { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
    { pubkey: RENT, isSigner: false, isWritable: false },
    { pubkey: PF_ACCOUNT, isSigner: false, isWritable: false },
    { pubkey: PF_PROGRAM_ID, isSigner: false, isWritable: false }
  ];
  console.log(`Buying [${tokenAddress}] tokenAmount = ${tokenOut}, solAmount = ${maxSolCost}`)
  const data = Buffer.concat([bufferFromUInt64('16927863322537952870'), bufferFromUInt64(tokenOut), bufferFromUInt64(maxSolCost)]);

  instructions.push(new TransactionInstruction({
    keys: keys,
    programId: PF_PROGRAM_ID,
    data: data
  }));

  return instructions
}

export async function solPFGetSellInstruction(
  _owner: string | PublicKey,
  tokenAddress: string,
  tokenBalance: number,
  slippage: number = 25): Promise<TransactionInstruction[] | undefined> {

  const coinData = await pfGetTokenDataByWeb3(tokenAddress);
  if (!coinData) {
    console.error('Failed to retrieve coin data...');
    return undefined;
  }

  const owner = solAddrPubKey(_owner)
  const token = new PublicKey(tokenAddress);

  const tokenAccountAddress = await getAssociatedTokenAddress(token, owner, false);
  const tokenAccountInfo = await heliusConnection.getAccountInfo(tokenAccountAddress);

  const instructions: TransactionInstruction[] = []
  let tokenAccount: PublicKey;
  if (!tokenAccountInfo) {
    instructions.push(
      createAssociatedTokenAccountInstruction(owner, tokenAccountAddress, owner, token)
    );
    tokenAccount = tokenAccountAddress;
  } else {
    tokenAccount = tokenAccountAddress;
  }

  const minSolOutput = Math.floor((tokenBalance! * (1 - (slippage / 100)) * coinData['virtual_sol_reserves']) / coinData['virtual_token_reserves']);

  const keys = [
    { pubkey: PF_GLOBAL, isSigner: false, isWritable: false },
    { pubkey: PF_FEE_RECIPIENT, isSigner: false, isWritable: true },
    { pubkey: token, isSigner: false, isWritable: false },
    { pubkey: new PublicKey(coinData['bonding_curve']), isSigner: false, isWritable: true },
    { pubkey: new PublicKey(coinData['associated_bonding_curve']), isSigner: false, isWritable: true },
    { pubkey: tokenAccount, isSigner: false, isWritable: true },
    { pubkey: owner, isSigner: false, isWritable: true },
    { pubkey: SYSTEM_PROGRAM_ID, isSigner: false, isWritable: false },
    { pubkey: PF_ASSOC_TOKEN_ACC_PROG, isSigner: false, isWritable: false },
    { pubkey: TOKEN_PROGRAM_ID, isSigner: false, isWritable: false },
    { pubkey: PF_ACCOUNT, isSigner: false, isWritable: false },
    { pubkey: PF_PROGRAM_ID, isSigner: false, isWritable: false }
  ];
  const data = Buffer.concat([bufferFromUInt64('12502976635542562355'), bufferFromUInt64(tokenBalance.toString()), bufferFromUInt64(minSolOutput)]);

  instructions.push(new TransactionInstruction({
    keys: keys,
    programId: PF_PROGRAM_ID,
    data: data
  }));

  return instructions
}

export async function solPFBuy(
  _signer: string | Keypair,
  tokenAddress: string,
  amount: number,
  slippage: number = 25,
  priorityFee: number = 0.1,
  jitoFee?: number,
  cnf?:any
): Promise<string> {
  try {
    const signer = solWalletKeyPair(_signer)
    if (!signer)
      return '';
    // solCheckTr(cnf)
    const instructions = await solPFGetBuyInstruction(signer.publicKey, tokenAddress, amount, slippage);
    if (!instructions) {
      console.error('Failed to retrieve buy instruction...');
      return 'fetch error';
    }

    const computeUnitPriceInstruction = ComputeBudgetProgram.setComputeUnitPrice({
      microLamports: priorityFee * (10 ** 6)
    });
    const recentBlockhashForSwap = await heliusConnection.getLatestBlockhash()
    const transaction = new VersionedTransaction(
      new TransactionMessage({
        payerKey: signer.publicKey,
        recentBlockhash: recentBlockhashForSwap.blockhash,
        instructions: [computeUnitPriceInstruction, ...instructions],
      }).compileToV0Message()
    )

    // solCheckTr(cnf)
    let signature
    if (jitoFee)
      signature = await solJitoSend(1, transaction, signer, jitoFee)
    // signature = await solJitoSendByApi(transaction, signer, jitoFee)
    else {
      transaction.sign([signer])
      signature = await solTrSendVersionedTransaction(transaction)
    }
    if (!signature) {
      // console.log(`[LIB] failed in sending transaction!`)
      return ''
    }
    // const signature = await solJitoSend(1, transaction, signer, 0.001)
    console.log('[LIB](PF) Buy transaction confirmed:', signature);
    return signature;
  } catch (error) {
    // console.log(`[SOL-LIB](solPFBuy) error :`, error);
    return ''
  }
}

export async function solPFSell(
  _signer: string | Keypair,
  tokenAddress: string,
  amount: number,
  slippage: number = 25,
  priorityFee: number = 0.1,
  jitoTip?: number
): Promise<string> {
  try {
    const signer = solWalletKeyPair(_signer)
    if (!signer)
      return '';
    const instructions = await solPFGetSellInstruction(signer.publicKey, tokenAddress, amount, slippage);
    if (!instructions) {
      // console.error('Failed to retrieve sell instruction...');
      return '';
    }
    const computeUnitPriceInstruction = ComputeBudgetProgram.setComputeUnitPrice({
      microLamports: priorityFee * (10 ** 6)
    });
    const recentBlockhashForSwap = await heliusConnection.getLatestBlockhash()
    const transaction = new VersionedTransaction(
      new TransactionMessage({
        payerKey: signer.publicKey,
        recentBlockhash: recentBlockhashForSwap.blockhash,
        instructions: [computeUnitPriceInstruction, ...instructions],
      }).compileToV0Message()
    )


    let signature
    if (jitoTip) {
      // signature = await solJitoSendByApi(transaction, signer, jitoTip)
      signature = await solJitoSend(1, transaction, signer, jitoTip)
    } else {
      transaction.sign([signer])
      signature = await solTrSendVersionedTransaction(transaction)
    }

    if (!signature) {
      // console.log(`[LIB] failed in sending transaction!`)
      return ''
    }
    console.log('[LIB](PF) Sell transaction confirmed:', signature);
    return signature;
  } catch (error) {
    // console.log(error);
    return ''
  }
}

export async function solPFFetchPrice(_token: string): Promise<number> {
  const coinData = await pfGetTokenDataByWeb3(_token);
  if (!coinData) {
    return 0
  }
  return coinData['virtual_sol_reserves'] / coinData['virtual_token_reserves']
}

export async function solPFGetTokensCreatedByWallet(wallet: string, limit: number): Promise<any[]> {
  try {
    const resp = await axios.get(`https://frontend-api.pump.fun/coins/user-created-coins/${wallet}?limit=${limit}&offset=0&includeNsfw=true`)
    return resp.data
  } catch (error) {
    return []
  }
}

export function solTrIsPumpfunBuy(transaction: any, token: string): boolean {
  if (transaction.meta.err)
    return false

  const version: any = transaction.version

  let accounts
  let items: any[]
  if (version === 'legacy') {
    accounts = transaction.transaction.message.accountKeys?.map((acc: PublicKey) => acc.toBase58())
    if (!accounts)
      return false

    const msgInstrs = transaction.transaction.message?.instructions
    const innerIstrs = transaction.meta.innerInstructions.map((i: any) => i.instructions).flat()
    if (msgInstrs)
      items = [...msgInstrs, ...innerIstrs]
    else
      items = innerIstrs
  } else if (!version) {
    accounts = transaction.transaction.message.staticAccountKeys?.map((acc: PublicKey) => acc.toBase58())
    if (!accounts)
      return false

    const msgInstrs = transaction.transaction.message?.compiledInstructions
    const innerIstrs = transaction.meta.innerInstructions.map((i: any) => i.instructions).flat()
    if (msgInstrs)
      items = [...msgInstrs, ...innerIstrs]
    else
      items = innerIstrs
  } else {
    return false
  }

  for (const item of items) {
    const keyIndex = item.accounts || item.accountKeyIndexes
    if (accounts[item.programIdIndex] !== PF_PROGRAM_ID.toBase58())
      continue

    if (keyIndex.length !== 12)
      continue

    const mint = accounts[keyIndex[2]]
    const decodedData = typeof item.data === 'string'
      ? [...bs58.decode(item.data)]
      : [...(item.data).values()]
    const cmdType = bytesToUInt64(decodedData.slice(0, 8));
    if (cmdType !== BigInt("16927863322537952870")) {
      continue
    }

    if (mint === token) {
      return true
    }
  }
  return false
}