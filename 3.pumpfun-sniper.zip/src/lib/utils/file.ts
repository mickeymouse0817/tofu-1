import fs from 'fs';

export function utilGetPrivateKeyListFromFile(filePath: string): string[] {

  const data = fs.readFileSync(filePath, 'utf8');

  // Regular expression to match prvKey values
  const prvKeyRegex = /prvKey:\s*"([^"]+)"/g;
  const privList = []
  // Extract all matches
  let matches;
  while ((matches = prvKeyRegex.exec(data)) !== null) {
    // output.write(matches[1] + '\n');
    // console.log(matches[1]); // Print the extracted prvKey
    privList.push(matches[1])
  }
  return privList
}