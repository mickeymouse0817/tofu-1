export function decodeBase64Fields(obj: any): any {
  if (typeof obj === "string") {
    return Buffer.from(obj, 'base64');
  } else if (Array.isArray(obj)) {
    return obj.map((item) => decodeBase64Fields(item));
  } else if (typeof obj === "object" && obj !== null) {
    const decodedObject: any = {};
    for (const key in obj) {
      // console.log(key)
      if (key === 'post_token_balances' || key === 'Type' || key === 'log_messages') {
        decodedObject[key] = obj[key]
      } else
        decodedObject[key] = decodeBase64Fields(obj[key]);
    }
    return decodedObject;
  }
  return obj;
}