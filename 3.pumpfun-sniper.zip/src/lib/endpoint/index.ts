import { Connection } from "@solana/web3.js";
import dotenv from "dotenv"

dotenv.config()

export const heliusConnection = new Connection(
  process.env.HELIUS_RPC ||
  process.env.ENDPOINT ||
  "",
  "processed");

export const confirmedConnection = new Connection(
  process.env.HELIUS_RPC ||
  process.env.ENDPOINT ||
  "",
  "confirmed");
