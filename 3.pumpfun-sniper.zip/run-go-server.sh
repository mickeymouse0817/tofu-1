#!/bin/bash

PORT=8089
GO_APP="adam"

# Check if the port is in use
if lsof -i:$PORT > /dev/null; then
  echo "Go app is already running on port $PORT."
else
  echo "Starting Go app..."
  ../1.go-pf-sniper-bot/$GO_APP &
  echo "Go app started."
fi