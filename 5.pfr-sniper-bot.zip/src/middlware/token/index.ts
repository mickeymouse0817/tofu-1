import { pfTokenGetInitialBuy } from "dv-sol-lib";
import { dbTokenAdd } from "../../db/db.service/service.token";

export async function tokenAdd(tokenInfo:any) {
  const initialBuy = await pfTokenGetInitialBuy(tokenInfo.address)
  await dbTokenAdd({...tokenInfo, initialBuy})
}