import { TokenModel } from "../db.model/model.tokens"

export async function dbTokenGet(address: string): Promise<any> {
  const token = await TokenModel.findOne({ address })
  return token
}

export async function dbTokenAdd(tokenInfo: any): Promise<any> {
  let token = await dbTokenGet(tokenInfo.address)
  if (!token) {
    token = new TokenModel(tokenInfo)
    await token.save()
  }

  return token
}