import { Document } from "mongodb";
import mongoose, { Schema } from "mongoose";

interface IToken {
  address: string;
  name: string;
  symbol: string;
  twitter: string;
  telegram: string;
  creator: string;
  initialBuy: number
  delayedOnPump: number;
  elapsedAfterKof: number;
}

const TokenSchema: Schema = new Schema({
  address: { type: String, required: true, unique: true },
  name: { type: String },
  symbol: { type: String },
  twitter: { type: String },
  telegram: { type: String },
  initialBuy: { type: Number },
  creator: { type: String, required: true },
  delayedOnPump: { type: Number },
  elapsedAfterKof: { type: Number },
})

export const TokenModel = mongoose.model<IToken>('Token', TokenSchema)