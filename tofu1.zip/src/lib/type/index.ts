import { BigNumberish } from "@raydium-io/raydium-sdk";
import { PublicKey } from "@solana/web3.js";

export interface SolWallet {
  pubKey: string | PublicKey;
  privKey: string;
}

export interface SolTokenMeta {
  name: string;
  symbol: string;
  logo: string;
}
export class Pair {
  address: string
  amount: BigNumberish
  decimal: number
  constructor(address: string = "", amount: BigNumberish = 0, decimal: number = 9) {
    this.address = address
    this.amount = amount
    this.decimal = decimal
  }
}

export interface SolRaydiumPoolSummary {
  id: string;
  base: Pair;
  quote: Pair;
  marketInfo: string;
  marketAcccount: any;
  lp: {
    total: number;
    remain: number;
    burnPercent: number;
    fluxBeamDeposit: boolean;
  }
  danger: {
    mintAuthDisabled: boolean;
    freezeAuthDisabled: boolean;
    lpBurned: boolean;
    top10Holders: boolean;
  }
}

export interface SolPairInfo {
  pair: string,
  baseToken: any,
  quoteToken: any,
  liquidity: {
    usd: number,
    base: number,
    quote: number
  },
  createdAt: number
}

export interface SolAsset {
  address: string,
  name: string,
  symbol?: string,
  amount: number
}

export interface SolTrSwapInfo {
  when: Date,
  who: string,
  where: string,
  what: string,
  how: string,
  sentAsset: SolAsset,
  rcvAsset: SolAsset,
  signature: string
}