import { Liquidity, LIQUIDITY_STATE_LAYOUT_V4, MAINNET_PROGRAM_ID, TOKEN_PROGRAM_ID } from "@raydium-io/raydium-sdk";
import { NATIVE_MINT } from "@solana/spl-token";
import { ConfirmedSignatureInfo, PublicKey } from "@solana/web3.js";
import { solAddrPubKey, solAddrStr } from "../address";
import { solDexscrGetPair, solJupiterGetPair } from "../3rdparty";
import { SolPairInfo } from "../type";
import { solRaydiumApiFetchPool } from "./raydium";
import { heliusConnection } from "../endpoint";
import bs58 from "bs58"
import { parse } from "path";
import { solNativePrice } from "../token";
import { OpenOrders } from "@project-serum/serum";
import { RAYDIUM_AUTHORITY_V4 } from "../constants";

let poolMap = new Map()

export async function solWeb3PoolMonitorStart() {
  const runTimestamp = Math.floor(new Date().getTime() / 1000);
  const RAYDIUM_LIQUIDITY_PROGRAM_ID_V4 = MAINNET_PROGRAM_ID.AmmV4;

  heliusConnection.onProgramAccountChange(
    RAYDIUM_LIQUIDITY_PROGRAM_ID_V4,
    async (updatedAccountInfo) => {
      const poolId = updatedAccountInfo.accountId.toString();
      const poolState = LIQUIDITY_STATE_LAYOUT_V4.decode(updatedAccountInfo.accountInfo.data);
      const poolOpenTime = parseInt(poolState.poolOpenTime.toString());
      let base = poolState.baseMint.toBase58()
      let quote = poolState.quoteMint.toBase58()
      if (base === NATIVE_MINT.toBase58()) {
        base = poolState.quoteMint.toBase58()
        quote = poolState.baseMint.toBase58()
      }
      const existing = poolMap.has(base);

      if (poolOpenTime > runTimestamp && !existing) {
        poolMap.set(base, poolId)
        console.log(`[LIB] --------------- HELIUS :: POOL Created:: baseToken = ${base}`)
      }
    },
    'finalized',
    [
      { dataSize: LIQUIDITY_STATE_LAYOUT_V4.span },
      {
        memcmp: {
          offset: LIQUIDITY_STATE_LAYOUT_V4.offsetOf('quoteMint'),
          bytes: NATIVE_MINT.toBase58(),
        },
      },
      {
        memcmp: {
          offset: LIQUIDITY_STATE_LAYOUT_V4.offsetOf('marketProgramId'),
          bytes: MAINNET_PROGRAM_ID.OPENBOOK_MARKET.toBase58(),
        },
      },
      {
        memcmp: {
          offset: LIQUIDITY_STATE_LAYOUT_V4.offsetOf('status'),
          bytes: bs58.encode([6, 0, 0, 0, 0, 0, 0, 0]),
        },
      },
    ],
  );
}

export async function solPoolFetchInfo(poolId: string): Promise<SolPairInfo | undefined> {
  try {
    const OPENBOOK_PROGRAM_ID = new PublicKey(
      "srmqPvymJeFKQ4zGQed1GFppgkRHL9kaELCbyksJtPX"
    );
    const poolAcc = await heliusConnection.getAccountInfo(new PublicKey(poolId), 'confirmed')
    if (!poolAcc)
      return undefined
    const parsed = LIQUIDITY_STATE_LAYOUT_V4.decode(poolAcc.data)
    let base = parsed.baseMint.toBase58()
    let quote = parsed.quoteMint.toBase58()
    let baseVault = parsed.baseVault
    let quoteVault = parsed.quoteVault
    let baseDecimal = 10 ** parsed.baseDecimal;
    let quoteDecimal = 10 ** parsed.quoteDecimal;
    if (base === NATIVE_MINT.toBase58()) {
      base = parsed.quoteMint.toBase58()
      quote = parsed.baseMint.toBase58()
      baseVault = parsed.quoteVault
      quoteVault = parsed.baseVault
      baseDecimal = 10 ** parsed.quoteDecimal;
      quoteDecimal = 10 ** parsed.baseDecimal;
    }

    if (quote !== NATIVE_MINT.toBase58())
      return undefined

    const baseTokenAmount = await heliusConnection.getTokenAccountBalance(baseVault);
    const quoteTokenAmount = await heliusConnection.getTokenAccountBalance(quoteVault);
    const openOrders = await OpenOrders.load(
      heliusConnection,
      new PublicKey(parsed.openOrders),
      OPENBOOK_PROGRAM_ID
    );
    const openOrdersBaseTokenTotal = openOrders.baseTokenTotal / baseDecimal;
    const openOrdersQuoteTokenTotal = openOrders.quoteTokenTotal / quoteDecimal;
    const bAmount = (baseTokenAmount.value?.uiAmount || 0) + openOrdersBaseTokenTotal
    const qAmount = (quoteTokenAmount.value?.uiAmount || 0) + openOrdersQuoteTokenTotal
    if (!bAmount || !qAmount)
      return undefined

    const solPrice = await solNativePrice()
    const liqUsd = (qAmount * solPrice) * 2
    return {
      pair: poolId,
      baseToken: base,
      quoteToken: quote,
      liquidity: {
        usd: liqUsd,
        base: bAmount,
        quote: qAmount
      },
      createdAt: 0
    }
  } catch (error) {
    return undefined
  }
}

export async function solPoolGetPairByTokenAddr(tokenAddr: string | PublicKey): Promise<SolPairInfo | undefined> {
  let pairInfo = undefined
  // 1. try to get from local data
  const poolId = poolMap.get(tokenAddr)
  if (poolId)
    pairInfo = await solPoolFetchInfo(poolId)
  if (pairInfo)
    return pairInfo

  // 2. try to get from dexscreener
  pairInfo = await solDexscrGetPair(tokenAddr)
  if (pairInfo)
    return pairInfo

  // 3. try to get from raydium api
  pairInfo = await solRaydiumApiFetchPool(solAddrStr(tokenAddr))
  if (pairInfo)
    return pairInfo

  // 4. try to get from rupiter api
  pairInfo = await solJupiterGetPair(solAddrStr(tokenAddr))
  return pairInfo
}
