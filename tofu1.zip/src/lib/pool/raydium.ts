import { BigNumberish, CurrencyAmount, InstructionType, Liquidity, LIQUIDITY_STATE_LAYOUT_V4, LiquidityPoolKeys, MARKET_STATE_LAYOUT_V3, Percent, SPL_ACCOUNT_LAYOUT, SPL_MINT_LAYOUT, splitTxAndSigners, Token, TOKEN_PROGRAM_ID, TokenAmount } from "@raydium-io/raydium-sdk";
import { AddressLookupTableAccount, Keypair, MessageV0, ParsedAccountData, ParsedInstruction, ParsedTransactionWithMeta, PartiallyDecodedInstruction, Signer, TransactionInstruction, TransactionMessage, VersionedTransaction } from "@solana/web3.js";
import { solWalletKeyPair } from "../wallet";
import { NATIVE_MINT } from "@solana/spl-token";
import { heliusConnection } from "../endpoint";
import { solJitoSendByApi } from "../transaction/jito";
import { PublicKey } from "@metaplex-foundation/js";
import { Pair, SolPairInfo, SolRaydiumPoolSummary } from "../type";
import { LOOKUP_TABLES } from "../address";
import { sleep } from "../utils";

const RAYDIUM_AMM_PROGRAM = new PublicKey("675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8")

export async function solRaydiumswapCalcAmountOut(poolKeys: LiquidityPoolKeys, amount: number | bigint, swapInDirection: boolean) {
  const poolInfo = await Liquidity.fetchInfo({ connection: heliusConnection, poolKeys })

  let currencyInMint = poolKeys.baseMint
  let currencyInDecimals = poolInfo.baseDecimals
  let currencyOutMint = poolKeys.quoteMint
  let currencyOutDecimals = poolInfo.quoteDecimals

  if (!swapInDirection) {
    currencyInMint = poolKeys.quoteMint
    currencyInDecimals = poolInfo.quoteDecimals
    currencyOutMint = poolKeys.baseMint
    currencyOutDecimals = poolInfo.baseDecimals
  }

  // const isRaw = rawAmountIn instanceof bigint
  const currencyIn = new Token(TOKEN_PROGRAM_ID, new PublicKey(currencyInMint), currencyInDecimals)
  const amountIn = new TokenAmount(currencyIn, amount, typeof amount === 'bigint')
  const currencyOut = new Token(TOKEN_PROGRAM_ID, new PublicKey(currencyOutMint), currencyOutDecimals)
  const slippage = new Percent(50, 100) // 50% slippage

  const { amountOut, minAmountOut, currentPrice, executionPrice, priceImpact, fee } = Liquidity.computeAmountOut({
    poolKeys,
    poolInfo,
    amountIn,
    currencyOut,
    slippage,
  })

  return {
    amountIn,
    amountOut,
    minAmountOut,
    currentPrice,
    executionPrice,
    priceImpact,
    fee,
  }
}

export async function solRaydiumBuildSwapTransaction(poolInfo: LiquidityPoolKeys, amountIn: TokenAmount, minAmountOut: TokenAmount | CurrencyAmount, signer: Keypair): Promise<VersionedTransaction | undefined> {
  const walletTokenAccount = await heliusConnection.getTokenAccountsByOwner(signer.publicKey, {
    programId: TOKEN_PROGRAM_ID,
  })
  const userTokenAccounts = walletTokenAccount.value.map((i) => ({
    pubkey: i.pubkey,
    programId: i.account.owner,
    accountInfo: SPL_ACCOUNT_LAYOUT.decode(i.account.data)
  }))
  const maxLamports = 100000
  let swapTransaction = undefined;
  try {
    // build inital tranaction
    const { innerTransactions } = await Liquidity.makeSwapInstructionSimple({
      connection: heliusConnection,
      makeTxVersion: 1,
      poolKeys: {
        ...poolInfo,
      },
      userKeys: {
        tokenAccounts: userTokenAccounts,
        owner: signer.publicKey,
      },
      amountIn: amountIn,
      amountOut: minAmountOut,
      fixedSide: 'in',
      config: {
        bypassAssociatedCheck: false,
      },
      computeBudgetConfig: {
        microLamports: maxLamports,
      },
    })
    const instructions = innerTransactions[0].instructions.filter(Boolean)
    const recentBlockhashForSwap = await heliusConnection.getLatestBlockhash()
    swapTransaction = new VersionedTransaction(
      new TransactionMessage({
        payerKey: signer.publicKey,
        recentBlockhash: recentBlockhashForSwap.blockhash,
        instructions: instructions,
      }).compileToV0Message()
    )
    return swapTransaction
  } catch (error) {
    console.log(`[LIB] Cannot build swap transaction. err = ${error}`)
    return undefined
  }
}

export async function solRaydiumBuildSwapTransactionNormal(
  poolKeys: LiquidityPoolKeys,
  amountIn: TokenAmount,
  amountOut: TokenAmount,
  signer: Keypair,
  _maxLamports: number = 0
): Promise<VersionedTransaction | undefined> {

  const maxLamports = _maxLamports || 1_000000 // 1 lamports 
  const tokenIn = amountIn.token
  const tokenOut = amountOut.token
  const owner = signer.publicKey

  const accIn = await heliusConnection.getTokenAccountsByOwner(owner, { mint: tokenIn.mint })
  const accOut = await heliusConnection.getTokenAccountsByOwner(owner, { mint: tokenOut.mint })
  const tokenAccounts = [accIn, accOut]
    .filter((acc: any) => acc?.value?.length ? true : false)
    .map((acc: any) => ({
      pubkey: acc.value[0].pubkey,
      programId: acc.value[0].account.owner,
      accountInfo: SPL_ACCOUNT_LAYOUT.decode(acc.value[0].account.data)
    }))
  const tokenAccountIn = Liquidity._selectTokenAccount({
    programId: TOKEN_PROGRAM_ID,
    tokenAccounts,
    mint: tokenIn.mint,
    owner,
    config: { associatedOnly: false },
  })
  const tokenAccountOut = Liquidity._selectTokenAccount({
    programId: TOKEN_PROGRAM_ID,
    tokenAccounts,
    mint: tokenOut.mint,
    owner,
  })

  const [amountInRaw, amountOutRaw] = [amountIn.raw, amountOut.raw]

  const frontInstructions: TransactionInstruction[] = []
  const endInstructions: TransactionInstruction[] = []
  const frontInstructionsType: InstructionType[] = []
  const endInstructionsType: InstructionType[] = []
  const signers: Signer[] = []
  const _tokenAccountIn = tokenAccountIn ? tokenAccountIn : await Liquidity._handleTokenAccount({
    programId: TOKEN_PROGRAM_ID,
    connection: heliusConnection,
    side: 'in',
    amount: amountInRaw,
    mint: tokenIn.mint,
    tokenAccount: tokenAccountIn,
    owner,
    payer: owner,
    frontInstructions,
    endInstructions,
    signers,
    bypassAssociatedCheck: false,
    frontInstructionsType,
    checkCreateATAOwner: false,
  })
  const _tokenAccountOut = tokenAccountOut ? tokenAccountOut : await Liquidity._handleTokenAccount({
    programId: TOKEN_PROGRAM_ID,
    connection: heliusConnection,
    side: 'out',
    amount: 0,
    mint: tokenOut.mint,
    tokenAccount: tokenAccountOut,
    owner,
    payer: owner,
    frontInstructions,
    endInstructions,
    signers,
    bypassAssociatedCheck: false,
    frontInstructionsType,
    checkCreateATAOwner: false,
  })

  const ins = Liquidity.makeSwapInstruction({
    poolKeys,
    userKeys: {
      tokenAccountIn: _tokenAccountIn,
      tokenAccountOut: _tokenAccountOut,
      owner,
    },
    amountIn: amountInRaw,
    amountOut: amountOutRaw,
    fixedSide: 'in',
  })
  const innerTransactions = await splitTxAndSigners({
    connection: heliusConnection,
    makeTxVersion: 1,
    computeBudgetConfig: { microLamports: maxLamports },
    payer: owner,
    innerTransaction: [
      { instructionTypes: frontInstructionsType, instructions: frontInstructions, signers },
      ins.innerTransaction,
      { instructionTypes: endInstructionsType, instructions: endInstructions, signers: [] },
    ],
    lookupTableCache: undefined,
  })

  const instructions = innerTransactions[0].instructions.filter(Boolean)
  const recentBlockhashForSwap = await heliusConnection.getLatestBlockhash()
  const swapTransaction = new VersionedTransaction(
    new TransactionMessage({
      payerKey: signer.publicKey,
      recentBlockhash: recentBlockhashForSwap.blockhash,
      instructions: instructions,
    }).compileToV0Message()
  )
  return swapTransaction
}

export async function solRaydiumSwap(
  _signer: string | Keypair,
  poolKeys: LiquidityPoolKeys,
  amount: number | bigint,
  isBuy: boolean,
  jitoFee: number | undefined = undefined): Promise<string | undefined> {
  const signer = solWalletKeyPair(_signer)
  if (!signer)
    return undefined
  const directionIn = poolKeys.baseMint.toString() === NATIVE_MINT.toString()
  const { minAmountOut, amountIn } = await solRaydiumswapCalcAmountOut(poolKeys, amount, isBuy === true ? directionIn : !directionIn)
  const transaction = await solRaydiumBuildSwapTransactionNormal(poolKeys, amountIn, minAmountOut as TokenAmount, signer)
  if (!transaction)
    return undefined

  let txHash
  if (jitoFee) {
    txHash = await solJitoSendByApi(transaction, signer, jitoFee)
  }
  else {
    transaction.sign([signer])
    txHash = await heliusConnection.sendTransaction(transaction, {
      skipPreflight: true,
      maxRetries: 5,
    })
    await heliusConnection.confirmTransaction(txHash);
  }
  return txHash
}

export async function getLpAmount(lpMint: PublicKey) {
  while (true) {
    try {
      const accInfo = await heliusConnection.getParsedAccountInfo(lpMint);
      const data: Buffer | ParsedAccountData | undefined = accInfo?.value?.data
      if (data) {
        const mintInfo = (data as ParsedAccountData).parsed?.info
        return Number(mintInfo.supply)
      }
    } catch (error) {
      console.log(`[LIB](SOL-LIB) cannot get parsed account of lpMint...`)
    }
    await sleep(100)
  }
}

export async function isDepositOnFluxBeam(mintAddress: string): Promise<boolean> {
  const fluxBeamAccounts = await heliusConnection.getProgramAccounts(new PublicKey("Lock1zcQFoaZmTk59sr9pB5daFE6Cs1K5eWyRLF1eju"), {
    commitment: "processed",
    encoding: "base64",
    filters: [
      {
        memcmp: {
          offset: 32,
          bytes: mintAddress,
        }
      },
      {
        memcmp: {
          offset: 65,
          bytes: ""
        }
      }
    ]
  });
  return fluxBeamAccounts.length > 0
}

export async function solRaydiumGetPoolSummary(poolId: string): Promise<SolRaydiumPoolSummary> {
  let poolDecoded: any = undefined
  let marketInfo: any = undefined
  let marketAcc: any = undefined
  while (true) {
    try {
      const poolAcc = await heliusConnection.getAccountInfo(new PublicKey(poolId))
      if (!poolAcc || !poolAcc.data) {
        // console.log(`[LIB](SOL-LIB)(getPoolSummary) Invalid Pool Account. account = ${JSON.stringify(poolAcc)}`)
        await sleep(100)
        continue
      }
      poolDecoded = LIQUIDITY_STATE_LAYOUT_V4.decode(poolAcc.data)
    } catch (error) {
      console.log(`[LIB] Cannot get pool account. error = ${error}, retrying...`)
      await sleep(100)
      continue
    }
    try {
      marketAcc = await heliusConnection.getAccountInfo(new PublicKey(poolDecoded.marketId))
      marketInfo = MARKET_STATE_LAYOUT_V3.decode(marketAcc.data)
      break
    } catch (error) {
      console.log(`[LIB] Cannot get market account. error = ${error}, retrying...`)
    }
    await sleep(100)
  }
  // console.log(`[LIB] POOL-DECODED :: ID(${poolId}) DECODED = ${JSON.stringify(poolDecoded)}`)
  // get amounts of pair
  let baseMintAddr: PublicKey
  let base: Pair
  let quote: Pair
  if (poolDecoded.baseMint.toString() === NATIVE_MINT.toString()) {
    baseMintAddr = poolDecoded.quoteMint
    base = new Pair(
      poolDecoded.quoteMint.toString(),
      poolDecoded.swapBaseInAmount / (10 ** poolDecoded.baseDecimal),
      poolDecoded.quoteDecimal
    )
    quote = new Pair(
      poolDecoded.baseMint.toString(),
      poolDecoded.swapQuoteOutAmount / (10 ** poolDecoded.quoteDecimal),
      poolDecoded.baseDecimal
    )
  } else {
    baseMintAddr = poolDecoded.baseMint
    base = new Pair(
      poolDecoded.baseMint.toString(),
      poolDecoded.swapQuoteInAmount / (10 ** poolDecoded.quoteDecimal),
      poolDecoded.baseDecimal
    )
    quote = new Pair(
      poolDecoded.quoteMint.toString(),
      poolDecoded.swapBaseOutAmount / (10 ** poolDecoded.baseDecimal),
      poolDecoded.quoteDecimal
    )
  }

  // danger info
  let mintAuthDisabled = false
  let freezeAuthDisabled = false

  let mintInfo
  while (true) {
    try {
      const baseMintAcc = await heliusConnection.getAccountInfo(baseMintAddr)
      if (baseMintAcc) {
        mintInfo = SPL_MINT_LAYOUT.decode(baseMintAcc.data)
        break
      }
    } catch (error) { }
    await sleep(100)
  }

  // console.log(`[LIB](solRaydiumGetPoolSummary) mintInfo =`, mintInfo)
  if (!mintInfo.mintAuthorityOption && !mintInfo.mintAuthority)
    mintAuthDisabled = true
  if (!mintInfo.freezeAuthorityOption ||
    (!mintInfo.freezeAuthority || mintInfo.freezeAuthority.toString() === '11111111111111111111111111111111'))
    freezeAuthDisabled = true
  const totalLp = poolDecoded.lpReserve
  const remainLp = await getLpAmount(poolDecoded.lpMint)
  const burnedLp = totalLp - remainLp
  const fluxBeamDeposit = await isDepositOnFluxBeam(baseMintAddr.toBase58())
  const burnnedPercent = (fluxBeamDeposit === true) ? 100 : (burnedLp * 100) / totalLp

  const lpBurned = burnnedPercent > 80;
  return {
    id: poolId,
    base,
    quote,
    marketInfo,
    marketAcccount: marketAcc,
    lp: {
      total: totalLp,
      remain: remainLp,
      burnPercent: burnnedPercent,
      fluxBeamDeposit: fluxBeamDeposit
    },
    danger: {
      mintAuthDisabled,
      freezeAuthDisabled,
      lpBurned,
      top10Holders: true
    }
  }
}

export async function solRaydiumPoolLpFromSignature(signature: string): Promise<number | undefined> {
  const txData: ParsedTransactionWithMeta | null =
    await heliusConnection.getParsedTransaction(signature, { maxSupportedTransactionVersion: 0, commitment: 'confirmed' });

  if (!txData)
    return undefined
  const instructions = txData.transaction.message.instructions
  const initInstruction: ParsedInstruction | PartiallyDecodedInstruction | undefined = instructions.find(i => i.programId.equals(RAYDIUM_AMM_PROGRAM)) as PartiallyDecodedInstruction | undefined
  if (!initInstruction)
    return undefined

  const lpMint = initInstruction.accounts[7]
  const innerInstructions = txData.meta?.innerInstructions
  if (!innerInstructions)
    return undefined

  let lpReserve: number | undefined = undefined
  for (let i = 0; i < innerInstructions.length; i++) {
    for (let y = 0; y < innerInstructions[i].instructions.length; y++) {
      const instruction = innerInstructions[i].instructions[y] as ParsedInstruction;
      if (!instruction.parsed) {
        continue;
      }
      if (
        instruction.parsed.type === 'mintTo' &&
        instruction.parsed.info.mint === lpMint.toBase58()
      ) {
        lpReserve = parseInt(instruction.parsed.info.amount)
      }
    }
  }
  return lpReserve
}

export async function solRaydiumApiFetchPool(tokenAddr: string): Promise<SolPairInfo | undefined> {
  let header = new Headers();
  header.append("accept", 'application/json');

  const requestOptions: RequestInit = {
    method: 'GET',
    headers: header,
    redirect: 'follow'
  };

  let respData: any = undefined
  const resp = await fetch(`https://api-v3.raydium.io/pools/info/mint?mint1=${tokenAddr}&mint2=${NATIVE_MINT.toBase58()}&poolType=all&poolSortField=default&sortType=desc&pageSize=10&page=1`, requestOptions)
    .then(response => response.json())
    .then(result => respData = result.data)
    .catch(error => respData = undefined)

  if (!respData || !respData.data || !resp.data.length)
    return undefined
  const data = respData.data[0]
  // console.log(`[LIB](SOL-LIB)(solRaydiumApiFetchPool) respData:`, respData)
  return {
    pair: data.id,
    baseToken: data.mintA.address === NATIVE_MINT.toBase58() ? data.mintB.address : data.mintA.address,
    quoteToken: data.mintA.address === NATIVE_MINT.toBase58() ? data.mintA.address : data.mintB.address,
    liquidity: {
      usd: data.price,
      base: data.mintA.address === NATIVE_MINT.toBase58() ? data.mintAmountB : data.mintAmountA,
      quote: data.mintA.address === NATIVE_MINT.toBase58() ? data.mintAmountA : data.mintAmountB,
    },
    createdAt: new Date(data.openTime).getTime()
  }
}