import { NATIVE_MINT } from "@solana/spl-token";
import { solAccountGetOwner } from "../address";
import { RAYDIUM_AUTHORITY_V4 } from "../constants";
import { heliusConnection } from "../endpoint";
import { SolAsset, SolTrSwapInfo } from "../type";
import { TokenAmount } from '@raydium-io/raydium-sdk';
import { LAMPORTS_PER_SOL, ParsedInstruction, ParsedTransactionWithMeta, PublicKey, TokenBalance } from "@solana/web3.js";
import { parse } from 'path';
import { solGetMintFromAccount, solTokenDecimals, solTokenGetMeta, solTokenGetName } from "../token";

// async function solInspectRaydiumSwap(parsedTr: ParsedTransactionWithMeta, signature: string): Promise<SolTrSwapInfo | undefined> {
//   let transInns: any[] = []
//   for (const inns of parsedTr?.meta?.innerInstructions!) {
//     transInns = inns.instructions.filter((i: any) => i?.parsed?.type === 'transfer')
//     if (transInns.length > 1)
//       break
//   }
//   if (transInns.length < 2)
//     return undefined

//   const sentInstr: any = transInns[0]
//   const rcvInst: any = transInns[1]
//   if (!sentInstr || !rcvInst)
//     return undefined

//   const when = new Date((parsedTr.blockTime as number) * 1000)
//   const who = sentInstr.parsed.info.authority
//   let how: string = ""
//   let where: string = ""

//   let destAcc = await heliusConnection.getParsedAccountInfo(new PublicKey(sentInstr.parsed.info.destination), 'finalized')
//   if (!destAcc)
//     return undefined

//   let accData: any = destAcc.value?.data
//   if (!accData)
//     return undefined

//   if (accData.parsed.info.owner === RAYDIUM_AUTHORITY_V4)
//     where = 'Raydium'

//   let decimals = accData.parsed.info.tokenAmount.decimals
//   const sentAsset: SolAsset = {
//     address: accData.parsed.info.mint,
//     name: "",
//     amount: Number(sentInstr.parsed.info.amount) / (10 ** decimals)
//   }

//   const acc = await heliusConnection.getParsedAccountInfo(new PublicKey(rcvInst.parsed.info.source), 'finalized')
//   if (!acc)
//     return undefined
//   accData = acc.value?.data
//   if (!accData)
//     return undefined
//   decimals = accData.parsed.info.tokenAmount.decimals
//   const rcvAsset: SolAsset = {
//     address: accData.parsed.info.mint,
//     name: "",
//     amount: Number(rcvInst.parsed.info.amount) / (10 ** decimals)
//   }
//   let what = ""
//   if (sentAsset.address === NATIVE_MINT.toBase58()) {
//     what = rcvAsset.address
//     how = 'buy'
//   } else {
//     what = sentAsset.address
//     how = 'sell'
//   }
//   if (where === "" && accData.parsed.info.owner === RAYDIUM_AUTHORITY_V4)
//     where = 'Raydium'
//   return {
//     when: when,
//     who: who,
//     where: where,
//     what: what,
//     how: how,
//     sentAsset: sentAsset,
//     rcvAsset: rcvAsset,
//     signature
//   }
// }
async function solTrInspectJupiter(
  signature: string,
  transInns: ParsedInstruction[],
  parsedTr: ParsedTransactionWithMeta
): Promise<SolTrSwapInfo | undefined> {

  const signers = parsedTr.transaction.message.accountKeys.filter((acc: any) => acc.signer === true)
  if (signers.length !== 1)
    return undefined
  const signer = signers[0].pubkey.toBase58()
  if (!signer)
    return undefined
  const instrInfos = transInns.filter((i: any) => i.parsed?.type === 'transfer')
    .map((ins: any) => ins?.parsed?.info)
  const when = new Date(parsedTr.blockTime! * 1000)
  const who = signer
  let tokenTxInstr: any = undefined
  for (const info of instrInfos) {
    if (info && info.amount && (await solGetMintFromAccount(info.source)) !== NATIVE_MINT.toBase58()) {
      tokenTxInstr = info
      break
    }
  }

  if (!tokenTxInstr)
    return undefined

  const how = tokenTxInstr.authority === who ? "sell" : "buy"
  let what
  let wTokenAsset: any
  let sentAsset: any
  let rcvAsset: any
  if (how === "buy") {
    // console.log(instrInfos)
    const walletInstr: any = instrInfos.find((i: any) => i?.authority === who)
    const tokenAcc = await heliusConnection.getParsedAccountInfo(new PublicKey(tokenTxInstr.source))
    if (!tokenAcc)
      return undefined
    wTokenAsset = tokenAcc.value?.data
    if (!wTokenAsset || !wTokenAsset.parsed?.info)
      return undefined
    what = wTokenAsset.parsed.info.mint

    try {
      sentAsset = {
        address: NATIVE_MINT.toBase58(),
        name: "",
        amount: (walletInstr.lamports || walletInstr.amount) / LAMPORTS_PER_SOL
      }
      rcvAsset = {
        address: what,
        name: "",
        amount: tokenTxInstr.amount / (10 ** wTokenAsset.parsed.info.tokenAmount.decimals)
      }
    } catch (error) {
      console.log(`[LIB](SOL-LIB)(solTrInspectJupiter)(sig: ${signature}) error =`, error)
    }
  } else if (how === "sell") {
    const tokenAcc = await heliusConnection.getParsedAccountInfo(new PublicKey(tokenTxInstr.destination))
    if (!tokenAcc)
      return undefined
    wTokenAsset = tokenAcc.value?.data
    if (!wTokenAsset || !wTokenAsset.parsed?.info)
      return undefined
    what = wTokenAsset.parsed.info.mint
    sentAsset = {
      address: what,
      name: "",
      amount: tokenTxInstr.amount / (10 ** wTokenAsset.parsed.info.tokenAmount.decimals)
    }
    const solBalance = (parsedTr.meta!.postBalances[0] - parsedTr.meta!.preBalances[0]) / LAMPORTS_PER_SOL
    const wsolPost = parsedTr.meta!.postTokenBalances?.find((b: TokenBalance) => b.owner === who && b.mint === NATIVE_MINT.toBase58())?.uiTokenAmount.uiAmount || 0
    const wsolPre = parsedTr.meta!.preTokenBalances?.find((b: TokenBalance) => b.owner === who && b.mint === NATIVE_MINT.toBase58())?.uiTokenAmount.uiAmount || 0;
    const wSolBalance = wsolPost - wsolPre
    const rcvAmount = wSolBalance + solBalance
    if (rcvAmount < 0)
      return undefined
    rcvAsset = {
      address: NATIVE_MINT.toBase58(),
      name: "",
      amount: rcvAmount
    }
  }
  return {
    when,
    who,
    where: "Jupiter",
    what,
    how,
    sentAsset,
    rcvAsset,
    signature
  }
}

async function solTrInspectPumpfun(
  signature: string,
  transInns: ParsedInstruction[],
  parsedTr: ParsedTransactionWithMeta
): Promise<SolTrSwapInfo | undefined> {

  const signer = (parsedTr.transaction.message.accountKeys.find((acc: any) => acc.signer === true))?.pubkey.toBase58()
  if (!signer)
    return undefined
  const instrInfos = transInns.filter((i: any) => i.parsed?.type === 'transfer')
    .map((ins: any) => ins?.parsed?.info)
  const when = new Date(parsedTr.blockTime! * 1000)
  const who = signer
  let tokenTxInstr: any = undefined
  for (const info of instrInfos) {
    if (info && info.amount && (await solGetMintFromAccount(info.source)) !== NATIVE_MINT.toBase58()) {
      tokenTxInstr = info
      break
    }
  }

  if (!tokenTxInstr)
    return undefined

  const how = tokenTxInstr.authority === who ? "sell" : "buy"
  let what
  let wTokenAsset: any
  let sentAsset: any
  let rcvAsset: any
  if (how === "buy") {
    const walletInstr: any = instrInfos.find((i: any) => i?.destination === tokenTxInstr.authority)
    const tokenAcc = await heliusConnection.getParsedAccountInfo(new PublicKey(tokenTxInstr.source))
    if (!tokenAcc)
      return undefined

    wTokenAsset = tokenAcc.value?.data
    if (!wTokenAsset || !wTokenAsset.parsed?.info)
      return undefined
    what = wTokenAsset.parsed.info.mint

    try {
      sentAsset = {
        address: NATIVE_MINT.toBase58(),
        name: "",
        amount: walletInstr.lamports / LAMPORTS_PER_SOL
      }
      rcvAsset = {
        address: what,
        name: "",
        amount: tokenTxInstr.amount / (10 ** wTokenAsset.parsed.info.tokenAmount.decimals)
      }
    } catch (error) {
      console.log(`[LIB](SOL-LIB)(solTrInspectPumpfun)(sig: ${signature}) error =`, error)
      return undefined
    }
  } else if (how === "sell") {
    const tokenAcc = await heliusConnection.getParsedAccountInfo(new PublicKey(tokenTxInstr.destination))
    if (!tokenAcc)
      return undefined

    wTokenAsset = tokenAcc.value?.data
    if (!wTokenAsset || !wTokenAsset.parsed?.info)
      return undefined
    what = wTokenAsset.parsed.info.mint
    sentAsset = {
      address: what,
      name: "",
      amount: tokenTxInstr.amount / (10 ** wTokenAsset.parsed.info.tokenAmount.decimals)
    }

    const solBalance = (parsedTr.meta!.postBalances[0] - parsedTr.meta!.preBalances[0]) / LAMPORTS_PER_SOL
    const wsolPost = parsedTr.meta!.postTokenBalances?.find((b: TokenBalance) => b.owner === who && b.mint === NATIVE_MINT.toBase58())?.uiTokenAmount.uiAmount || 0
    const wsolPre = parsedTr.meta!.preTokenBalances?.find((b: TokenBalance) => b.owner === who && b.mint === NATIVE_MINT.toBase58())?.uiTokenAmount.uiAmount || 0;
    const wSolBalance = wsolPost - wsolPre
    const rcvAmount = wSolBalance + solBalance
    if (rcvAmount < 0)
      return undefined
    rcvAsset = {
      address: NATIVE_MINT.toBase58(),
      name: "",
      amount: rcvAmount
    }
  }

  return {
    when,
    who,
    where: "PumpFun",
    what,
    how,
    sentAsset,
    rcvAsset,
    signature
  }
}

async function solTrInspectRaydium(
  signature: string,
  transInns: ParsedInstruction[],
  parsedTr: ParsedTransactionWithMeta
): Promise<SolTrSwapInfo | undefined> {

  // console.log(`------------------ :: `, JSON.stringify(transInns))
  const signers = (parsedTr.transaction.message.accountKeys.filter((acc: any) => acc.signer === true)).map((ak: any) => ak?.pubkey.toBase58())
  // console.log(`[LIB] signer =`, signer)
  if (!signers || !signers.length)
    return undefined

  const instrInfos = transInns.filter((i: any) => i.parsed?.type === 'transfer')
    .map((ins: any) => ins?.parsed?.info)

  const walletInstr = instrInfos.find((i: any) => signers.includes(i.authority))
  if (!walletInstr)
    return undefined

  const who = walletInstr.authority
  const when = new Date(parsedTr.blockTime! * 1000)
  const raydiumInstr = instrInfos.find((i: any) => i.authority === RAYDIUM_AUTHORITY_V4)
  if (!raydiumInstr)
    return undefined

  let what
  let how
  const srcMint = await solGetMintFromAccount(raydiumInstr.source)
  if (srcMint) {
    how = srcMint === NATIVE_MINT.toBase58() ? 'sell' : 'buy'
    what = srcMint === NATIVE_MINT.toBase58() ? undefined : srcMint
  } else {
    const dstMint = await solGetMintFromAccount(raydiumInstr.destination)
    if (dstMint) {
      how = dstMint === NATIVE_MINT.toBase58() ? 'sell' : 'buy'
      what = dstMint === NATIVE_MINT.toBase58() ? undefined : dstMint
    }
  }

  if (!what) {
    const srcMint = await solGetMintFromAccount(walletInstr.source)
    if (srcMint) {
      what = srcMint === NATIVE_MINT.toBase58() ? undefined : srcMint
    } else {
      const dstMint = await solGetMintFromAccount(walletInstr.destination)
      if (dstMint) {
        what = dstMint === NATIVE_MINT.toBase58() ? undefined : dstMint
      }
    }
  }

  if (!how || !what)
    return undefined

  let sentAsset: any
  let rcvAsset: any
  const decimals = await solTokenDecimals(what)
  if (how === 'buy') {
    const walletInstr = instrInfos.find((i: any) => i.authority === who)
    sentAsset = {
      address: NATIVE_MINT.toBase58(),
      name: "SOL",
      amount: Number(walletInstr.amount) / LAMPORTS_PER_SOL
    }
    rcvAsset = {
      address: what,
      name: (await solTokenGetName(what))[1],
      amount: Number(raydiumInstr.amount) / (10 ** decimals)
    }
  } else { // sell
    const walletInstr = instrInfos.find((i: any) => i.authority === who)
    sentAsset = {
      address: what,
      name: (await solTokenGetName(what))[1],
      amount: Number(walletInstr.amount) / (10 ** decimals)
    }
    rcvAsset = {
      address: NATIVE_MINT.toBase58(),
      name: "SOL",
      amount: Number(raydiumInstr.amount) / LAMPORTS_PER_SOL
    }
  }

  return {
    when,
    who,
    where: "Raydium",
    what,
    how,
    sentAsset,
    rcvAsset,
    signature
  }
}

export async function solTrSwapInspect(signature: string, platform: string | undefined = undefined, filterList?: string[]): Promise<SolTrSwapInfo | undefined> {
  // console.log(`[LIB](solTrSwapInspect) signatures :`, signature)
  const parsedTr = await heliusConnection.getParsedTransaction(signature, { maxSupportedTransactionVersion: 0, commitment: 'finalized' })
  // console.log(`[LIB](SOL-LIB)(solTrSwapInspect) parseTr :`, JSON.stringify(parsedTr))
  if (!parsedTr
    || !parsedTr.meta
    || parsedTr.meta.err
    || !parsedTr.meta.innerInstructions
  )
    return undefined

  let transInns: any[] = []
  for (const inns of parsedTr.meta.innerInstructions) {
    // transInns = inns.instructions.filter((i: any) => i?.parsed?.type === 'transfer')
    // if (inns.instructions.find((i: any) => i?.parsed?.type === 'transfer')) {
    //   transInns = inns.instructions
    //   break
    // }
    transInns = [
      ...transInns,
      ...inns.instructions.filter((i: any) => i?.parsed?.type === 'transfer' && i?.program === 'spl-token')
    ]
  }
  if (transInns.length < 2)
    return undefined

  switch (platform) {
    case "Raydium":
      // return await solTrInspectRaydium(transInns, parsedTr.blockTime!, signature, filterList)
      return await solTrInspectRaydium(signature, transInns, parsedTr)
    case "PumpFun":
      return await solTrInspectPumpfun(signature, transInns, parsedTr)
    case "Jupiter":
      return await solTrInspectJupiter(signature, transInns, parsedTr)
    default:
      break;
  }
  return undefined
}