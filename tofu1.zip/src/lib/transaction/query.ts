import { LAMPORTS_PER_SOL, PublicKey } from "@solana/web3.js";
import { confirmedConnection, heliusConnection } from "../endpoint";
import { getCurrentTimestamp, sleep } from "../utils";
import { RAYDIUM_AUTHORITY_V4 } from "../constants";
import { solAddrPubKey } from "../address";
import { solBlockGetSlotForTimestamp } from "../block";

export async function solTrGetBalanceChange(signature: string): Promise<number> {

  let retryCnt = 0
  let transaction
  while (retryCnt++ < 30) {
    try {
      transaction = await heliusConnection.getTransaction(signature, { maxSupportedTransactionVersion: 0, commitment: "confirmed" });
      if (transaction)
        break
    } catch (error) {
      console.log(error)
    }
    await sleep(100)
  }

  if (!transaction)
    return 0

  const preBalances = transaction.meta?.preBalances;
  const postBalances = transaction.meta?.postBalances;

  if (!preBalances || !postBalances)
    return 0

  const balanceChanges = preBalances.map((preBalance, i) => postBalances[i] - preBalance);
  const balance = balanceChanges[0]
  return balance / LAMPORTS_PER_SOL;

}

export async function getSlotFromTransactionHash(txHash: string): Promise<number> {
  const transaction = await heliusConnection.getTransaction(txHash, { commitment: 'confirmed', maxSupportedTransactionVersion: 0 });
  if (transaction) {
    return transaction.slot;
  } else {
    return 0;
  }
}

export async function solTrQueryTransactions(
  addr: string | PublicKey,
  callback:any = undefined,
  startTimestamp: number = 0,
  endTimestamp: number = 0): Promise<number> {
  
  let startSlot = await solBlockGetSlotForTimestamp(startTimestamp)
  let endSlot = await solBlockGetSlotForTimestamp(endTimestamp)
  let totalCount = 0
  console.log(`[LIB](SOL-LIB)(solTrQueryTransactions) from(${startTimestamp}:${startSlot}) to(${endTimestamp}:${endSlot})`)
  
  if (startSlot && endSlot) {
    while (startSlot < endSlot) {
      const signatures = await confirmedConnection.getConfirmedSignaturesForAddress(
        solAddrPubKey(addr), 
        startSlot, 
        endSlot
      )
      totalCount += signatures.length
      if (callback) {
        callback(signatures)
      }
      endSlot = Math.min(await getSlotFromTransactionHash(signatures.at(-1)!), await getSlotFromTransactionHash(signatures.at(0)!))
      console.log(`[LIB](SOL-LIB) (solTrQueryTransactions) count = ${signatures.length}, slot:(${startSlot}/${endSlot})`)
      // results = [...results, ...signatures]
    }
    return totalCount
  }
  return 0
}
