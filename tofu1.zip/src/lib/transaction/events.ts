import { Context, Logs, PublicKey } from "@solana/web3.js";
import { heliusConnection } from "../endpoint";
import { solTrSwapInspect } from "./analyze";
import { SolTrSwapInfo } from "../type";
import { RAYDIUM_AUTHORITY_V4 } from "../constants";

export async function solTrEvWalletStart(address: string, callback:any = undefined): Promise<any> {
  heliusConnection.onLogs(
    new PublicKey(address),
    ({ err, logs, signature }: Logs, ctx: Context) => {
      if (err) return
      if (logs.filter((l:string) => l.includes('Instruction: Transfer')).length < 2)
        return
      if (callback)
        callback(signature)
    }, "finalized")
}

// async function raydiumEventCallback({ logs, err, signature }: { logs: any, err: any, signature: any }) {
//   const searchInstruction: string = "initialize2"
//   if (err) return;
//   if (logs && logs.some(log => log.includes(searchInstruction))) {
//     console.log(`+++++++++++++++++++++ WEB3 Detection (HELIUS) : ${signature} `)
//     if (trProcessCallback)
//       await trProcessCallback(signature)
//   }
// }
