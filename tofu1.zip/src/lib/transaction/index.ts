import { ComputeBudgetProgram, Keypair, TransactionInstruction, TransactionMessage, VersionedTransaction } from "@solana/web3.js";
import { heliusConnection, quicknodeConnection } from "../endpoint"
import { sleep } from "../utils"
import { promises } from "dns";
export * from "./query"
export * from "./analyze"
export * from "./events"

export const dummyUnitLimit = ComputeBudgetProgram.setComputeUnitLimit({
  units: 15000
});
export const dummyUnitPrice = ComputeBudgetProgram.setComputeUnitPrice({
  microLamports: 100000
});

export async function solTrGetTimestamp(signature: string): Promise<{ timestamp: number, blockNumber: number } | undefined> {
  let trResp
  let retryCnt = 0
  while (retryCnt++ < 10) {
    try {
      trResp = await heliusConnection.getTransaction(signature, { commitment: "confirmed", maxSupportedTransactionVersion: 2.0 })
      if (trResp && trResp.blockTime)
        break
    } catch (error) { }
    await sleep(100)
  }

  // console.log(`[LIB](SOL-LIB)(solTrGetTimestamp) blockTime = ${trWithMeta?.blockTime}, slot = ${trWithMeta?.slot}`)
  if (trResp?.blockTime)
    return {
      timestamp: new Date(trResp.blockTime * 1000).getTime(),
      blockNumber: trResp.slot
    }

  return undefined
}

export async function solTrCreateAndSendV0Tx(signer: Keypair, txInstructions: TransactionInstruction[]) {
  // Step 1 - Fetch Latest Blockhash
  let latestBlockhash = await heliusConnection.getLatestBlockhash('finalized');
  console.log("   ✅ - Fetched latest blockhash. Last valid height:", latestBlockhash.lastValidBlockHeight);

  // Step 2 - Generate Transaction Message
  const messageV0 = new TransactionMessage({
    payerKey: signer.publicKey,
    recentBlockhash: latestBlockhash.blockhash,
    instructions: txInstructions
  }).compileToV0Message();
  console.log("   ✅ - Compiled transaction message");
  const transaction = new VersionedTransaction(messageV0);

  // Step 3 - Sign your transaction with the required `Signers`
  transaction.sign([signer]);
  console.log("   ✅ - Transaction Signed");

  // Step 4 - Send our v0 transaction to the cluster
  const txid = await heliusConnection.sendTransaction(transaction, { maxRetries: 5 });
  console.log("   ✅ - Transaction sent to network");

  // Step 5 - Confirm Transaction 
  const confirmation = await heliusConnection.confirmTransaction({
    signature: txid,
    blockhash: latestBlockhash.blockhash,
    lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
  });
  if (confirmation.value.err) { throw new Error("   ❌ - Transaction not confirmed.") }
  console.log('🎉 Transaction succesfully confirmed!', '\n', `https://explorer.solana.com/tx/${txid}?cluster=mainnet`);
}

export async function solTrSendVersionedTransaction(transaction: VersionedTransaction): Promise<string> {
  const txid = await quicknodeConnection.sendTransaction(transaction, { maxRetries: 5 });
  let latestBlockhash = await quicknodeConnection.getLatestBlockhash('finalized');
  const confirmation = await quicknodeConnection.confirmTransaction({
    signature: txid,
    blockhash: transaction.message.recentBlockhash,
    lastValidBlockHeight: latestBlockhash.lastValidBlockHeight
  });
  if (confirmation.value.err) { throw new Error("   ❌ - Transaction not confirmed.") }
  return txid
}