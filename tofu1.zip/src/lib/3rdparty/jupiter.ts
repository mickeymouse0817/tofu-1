import { NATIVE_MINT } from "@solana/spl-token"
import { SolPairInfo } from "../type"

//Fetch token prices in USD using Jup pricing APIs 
export async function solJupiterGetTokenPrice(tokenAddr: string) {
  const tokenPrice = await (await fetch(`https://price.jup.ag/v4/price?ids=${tokenAddr}`)).json()
  return tokenPrice.data[tokenAddr]?.price || 0
}

export async function solJupiterGetPair(tokenAddr: string): Promise<SolPairInfo|undefined> {
  const resp = await (await fetch(
    `https://stats.jup.ag/coingecko/tickers?ticker_id=${NATIVE_MINT.toBase58()}_${tokenAddr}`
  )).json()
  return undefined
}