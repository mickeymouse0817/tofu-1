const URL_PRICE = "https://public-api.birdeye.so/defi/price"
const API_KEY = "c482eaf56d7d4faaa96c51100c3c32e1"

export async function birdeyeGetTokenPrice(tokenAddr: string): Promise<number> {
  let header = new Headers();
  header.append("x-api-key", API_KEY);

  const requestOptions: RequestInit = {
    method: 'GET',
    headers: header,
    redirect: 'follow'
  };

  let priceData: any
  await fetch(`${URL_PRICE}?address=${tokenAddr}`, requestOptions)
    .then(response => response.json())
    .then(result => { priceData = result.data })
    .catch(error => { priceData = undefined });

  const price = priceData?.value || 0
  return price
}