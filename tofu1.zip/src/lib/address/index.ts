const splToken = require('@solana/spl-token');

import { Keypair, PublicKey } from "@solana/web3.js";
import { solWalletImport } from "../wallet";
export * from "./lookup_table"
export * from "./query"

export function solAddrPubKey(addr: string | PublicKey | Keypair): PublicKey {
  if (addr instanceof Keypair)
    return addr.publicKey
  if (addr instanceof PublicKey)
    return addr
  return new PublicKey(addr)
}

export function solAddrStr(addr: string|PublicKey|Keypair): string {
  if (addr instanceof Keypair)
    return addr.publicKey.toBase58()
  if (addr instanceof PublicKey)
    return addr.toBase58()
  return addr
}

export function solKeyPair(key: string|Keypair): Keypair|undefined {
  if (key instanceof Keypair)
    return key
  const keyPair = solWalletImport(key)
  return keyPair
}