import { AddressLookupTableAccount, AddressLookupTableProgram, Keypair, PublicKey } from "@solana/web3.js";
import { heliusConnection } from "../endpoint";
import { LOOKUP_TABLE_ADDRS } from "../constants";
import { solTrCreateAndSendV0Tx } from "../transaction";

export let LOOKUP_TABLES: AddressLookupTableAccount[] = []

export async function solAddrInitLookupTables(_lookup_tables: string[] | undefined = undefined) {

  const lookup_tables = _lookup_tables ? _lookup_tables : LOOKUP_TABLE_ADDRS
  for (const la of lookup_tables) {
    const lt = (await heliusConnection.getAddressLookupTable(new PublicKey(la))).value;
    if (lt) {
      console.log(`[LIB](SOL-LIB)(ADDR)(solAddrInitLookupTables) Adding Lookup table:`, lt.key.toBase58())
      LOOKUP_TABLES.push(lt)
    } else {
      console.log(`[LIB](SOL-LIB)(ADDR)(solAddrInitLookupTables) invalid lookup table address:`, la)
    }
  }
}

export async function solAddrCreateLookupTable(signer: Keypair) {
  // Step 1 - Get a lookup table address and create lookup table instruction
  const [lookupTableInst, lookupTableAddress] =
    AddressLookupTableProgram.createLookupTable({
      authority: signer.publicKey,
      payer: signer.publicKey,
      recentSlot: await heliusConnection.getSlot(),
    });

  // Step 2 - Log Lookup Table Address
  console.log("Lookup Table Address:", lookupTableAddress.toBase58());

  // Step 3 - Generate a transaction and send it to the network
  solTrCreateAndSendV0Tx(signer, [lookupTableInst]);
}

export async function solAddrLookupTableAdd(signer: Keypair, lookupAddress: string, addresses: string[]) {
  // Step 1 - Create Transaction Instruction
  const addAddressesInstruction = AddressLookupTableProgram.extendLookupTable({
      payer: signer.publicKey,
      authority: signer.publicKey,
      lookupTable: new PublicKey(lookupAddress),
      addresses: addresses.map(addr => new PublicKey(addr)),
  });
  // Step 2 - Generate a transaction and send it to the network
  await solTrCreateAndSendV0Tx(signer, [addAddressesInstruction]);
  console.log(`Lookup Table Entries: `,`https://explorer.solana.com/address/${lookupAddress}/entries?cluster=mainnet`)
}

export function solAddrGetLookupTable() {
  return LOOKUP_TABLES
}