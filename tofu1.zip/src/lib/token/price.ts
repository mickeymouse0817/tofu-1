import { Connection } from "@solana/web3.js"
import { birdeyeGetTokenPrice, solJupiterGetTokenPrice } from "../3rdparty"
import { heliusConnection } from "../endpoint"
import { solPoolGetPairByTokenAddr } from "../pool/query"

const CLUSTER = 'mainnet-beta'

export async function solTokenPrice(tokenAddr: string): Promise<number> {

  let price

  const pairInfo = await solPoolGetPairByTokenAddr(tokenAddr)
  if (pairInfo)
    return pairInfo.liquidity.usd / pairInfo.liquidity.base / 2

  price = await solJupiterGetTokenPrice(tokenAddr)
  if (price)
    return price

  price = await birdeyeGetTokenPrice(tokenAddr)
  if (price)
    return price

  return 0;
}

export async function solTokenPriceHook() {
  import("@pythnetwork/client")
    .then()
  const { getPythClusterApiUrl, getPythProgramKeyForCluster, PriceStatus, PythConnection } = await import("@pythnetwork/client")
  const pythConnection = new PythConnection(heliusConnection, getPythProgramKeyForCluster(CLUSTER))
  pythConnection.onPriceChange((product: any, price: any) => {
    console.log(`${product.symbol}: $${price.price} \xB1$${price.confidence} Status: ${PriceStatus[price.status]}`)
  })  
}