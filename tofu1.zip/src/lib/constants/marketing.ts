const marketingInfo = {
  traders: {
    good: [
      "2ccKVjpay62JzM3ucpnTRdRkA5kZe4EXKXDDMXfpnkgg",
      "CGsqR7CTqTwbmAUTPnfg9Bj9GLJgkrUD9rhjh3vHEYvh",
      "HQ8bGKf7YZzpx9jCH8mhri7SLziQQd3cbDUovebExTRo",
      "MAXNBGdQNWsFAj9ghv19ZZ61xdDveUqvJ7aZbpNE87P",
      "3jtmKtAVdc1YKVQa8Xp1GaDt4DcdLDURfSTq4qXApF9P",
      "HXAb73vRTdU3ih1eCGVy3Z2DybYDDvH2w6NTNtoUKciX"
    ],
    bad: [
      "29BjsvgtMuUGxU232v4v1z2a8dxhtXM8d8sL7NYZ8FXc",
      "5hGK1q6oquJZgvUAj7ov76Y6VDDAequtYqWUYGEsEM5Z",
      "6iH6YA7TpZLEZ6NVSztZ6ewP8YAnm6MLJWr7KwwgTotm"
    ]
  },
  marketMaker: {
    whitelist: [
      "54VksUTvmq1tgfjUqjZX2iXGqxNLMbErKYPYjHkNcZcW",
      "EyfUbafmeYZL2tcC1rdh3EGv9JyAbn23bvz4zceWXnWn"
    ],
    blacklist: [
      "C7N14nGpGfjgJSujkLMFGr9rUdUv9qWiyGv3EQ9QU37Z",
      "FZbCqNKQ74UtswCG92w9RTdDYAKogd2sCGygpRGzYH3g",
      "8uiWtF4sMGfFgTYD1ASia6b9qeNL5Emb6MTMjqYf8jbx", // fake pumpfun
      "iJLwhBNSvLiQSaFA95vFSq42BfBD3e8aqwMQ65kUJjg", // fake pump
      "AgcU9VqgcEJEBf69yFKDoicg92vfvRVRYnp9NJe8tzSU",
      "6omxi9LbikDsYLhMrUaGfZzRL7UrieXayuRoA6HD135S",
      "BHxDowwHn5vuEd1ZvxsEE82JVdRcS4S78Xc4KrU1dwxY",
      "39jhVbvvKJzeoBiZRaTxLaFDachKeGYGSsyjzWgwHSPp"
    ],
    pumpfun: "39azUYFWPz3VHgKCf3VChUwbpURdCHRxjWVowf5jUJjg"
  },
  rugged: [
    "3C5LEykCf4TY6tqHHSvv9PKoQorJCXhK99diAjePHFUu",
    "5Zjf6vsNqjQhGHkqfA31XPwgahx6iufMB83WT1rdpump"
  ],
  transactions: {
    blx_jito: "4J1mdw9m51TcTiPY9pQf3FaAT73rhbiHkWkwPcfk8epokzVGYivAaNDb6aYHVyPpZzAKG28d63LVEJCuWY6h3C2N"
  },
  tradable_tokens: [
    "AfWVQCc8k8jHJWHdoGcTGsMCsNcwAFnziq8ZgCWVpump",
    "BGzKeCc7ge35JWuVZu4gx8KSZpBdLVBLrwekJhRnpump",
    "DztroDVaThoTxE7q9Mrg5rXTATqTPCm2uijXwUUDpump",
    "Eyt3iDq7aWebvoTZGRiUEi53Ycbv6Kqws93GZE6ypump",
    "HzMiBNxMhtyKomjtoq3vj2srQXF6DfwjtK7KU3Ycpump",
    "8HtfJc49kCpR8JtPJktBeniQVxBoi2L6Y7tWRafHpump",
    "HaGQhyfR8GQdQpmrzhPXsw6YsvxeQ1nh3Ciyh73mpump",
    "5cvR57p5hKNQxddCjs8FMC5HwsVKWqhBzPfdFFUMpump",
    "CoTFAqZtfTJSn847CP87Jxz4hCuBTJeB83MMaY2VSPC7",
    "7sNg5i7r9RRiQqSJmswKuADsnnhPmRyDZNNjKf5npump",
    "4TQ8Grmh3HUtBDpzoA9fS6xL8HQtAKpUZ5ByaUttpump",
    "2QxY3MRiPLJzp6XgWWrgs3VaUMJxFhZbX4BDU8nGpump", // 12000 %
    "HbhQ9Fwrqn4VEjEnvFh2iBRp69LSaY7gYQjjb4JnTJGx",
    "rs5KL7r3ez7f37tKzkcDCZFUSpV64ceei8paMnEpump",
    "EVBKeKEy2qKYDwDHEt4HYVaG4fJxfPVMePyU1crDpump",
    "2TTJZzWbfaidWwAGHsGbCnTc7JzLn7zn81aZLPpJpump",
    "AFVRBLSAPNrbBUjyLfYRTsE93LX4wc29kvVLZu2epump",
    "DBTR9T7KFrPbcwSMadh16mYHb7iQ6HFMEXMSfwiapump",
    "F1JGgw4rcs9Q21mYkPV96WqLRbCszLwSpAPpAfEvhWgT",
    "9KTocWvVdQAtBN47EFfJXhWqTziVXmJatQfVq3dYpump",
    "2XFyjCNQLqDUhMo4GtfjGvMdB5xpAdA59ZqyvE7QPUmp",
    "MoahWnsQPFtQUxmfkMuHYvPGLSFaZtNtH7gdynBpump",
  ],

  my_first_blocks: [
    "https://www.dextools.io/app/en/solana/pair-explorer/EFXyMfArJVzxLf19abSi7nTABkMYBR78zRTkC1gR57K6?t=1724215110717",
    "https://www.dextools.io/app/en/solana/pair-explorer/AA4gsNhyXpyDXN995Y2Y7N4SZvUypBtFAvwHdgTuWTSM?t=1724216489975",
    "https://www.dextools.io/app/en/solana/pair-explorer/J55MgXJpnnZMrNgatK1oJe17oPWmF8uEyHiwMyCJHnh2?t=1724216489975",
    "https://www.dextools.io/app/en/solana/pair-explorer/FDQKAAjQURL6ABXam9JrUWJnoPASCUZcX9iGyhUEJr5p?t=1724216489975",
    "https://www.dextools.io/app/en/solana/pair-explorer/96E1YDp5ZTHUNtoUU1KUed6p73JVu9yZRS27yzgsdzZg?t=1724216489975",
  ]
}
