export function bufferFromUInt64(value: number | string) {
  let buffer = Buffer.alloc(8);
  buffer.writeBigUInt64LE(BigInt(value));
  return buffer;
}

export function bytesToUInt64(bytes: number[]): bigint {
  if (bytes.length !== 8) {
    throw new Error("Input array must have exactly 8 bytes.");
  }
  return BigInt(bytes[0]) |
    (BigInt(bytes[1]) << BigInt(8)) |
    (BigInt(bytes[2]) << BigInt(16)) |
    (BigInt(bytes[3]) << BigInt(24)) |
    (BigInt(bytes[4]) << BigInt(32)) |
    (BigInt(bytes[5]) << BigInt(40)) |
    (BigInt(bytes[6]) << BigInt(48)) |
    (BigInt(bytes[7]) << BigInt(56));
}
