import { botStart } from "./bot";
import { grpcLUTCallback, grpcPFMintAuthCallback, grpcPFProgramCallback } from "./detection";
import { solGrpcStart, solPFGetTokensCreatedByWallet } from "./lib/3rdparty";
import { PF_FEE_RECIPIENT, PF_MINT_AUTHORITY, PF_PROGRAM_ID } from "./lib/3rdparty/pump.fun/constants";

export const LUT = 'AddressLookupTab1e1111111111111111111111111'

async function main() {
  try {
    console.log(`---------------------------------------`)
    console.log(`🤖 Starting TG bot ...`)
    botStart()
    console.log(`---------------------------------------`)
    console.log(`👀 Starting monitor handlers ...`)
    solGrpcStart([LUT], grpcLUTCallback)
    solGrpcStart([PF_MINT_AUTHORITY], grpcPFMintAuthCallback)
    solGrpcStart([PF_FEE_RECIPIENT.toBase58()], grpcPFProgramCallback)
  } catch (error:any) {
    console.error(`❌ Error : ${error.message}`)
  }
}

main()