import { LAMPORTS_PER_SOL } from '@solana/web3.js';
import bs58 from 'bs58'
import { LUT } from '.';
import { addLutTemporary, buyingTokenAdd, buyingTokenFind, buyingTokenIncreaseBuyCount, isCreateTokenExceeds, temporayLUT, WhitelistAdd, WhitelistExist, WhitelistRemove } from './whitelist';
import { buy } from './trade';
import { PF_CMD_BUY, PF_CMD_SELL, PF_FEE_RECIPIENT, PF_MINT_AUTHORITY, PF_PROGRAM_ID, pfGetTokenDataByApi, reportDetectionTime, solTrIsPumpfunBuy } from './lib/3rdparty';
import { config } from './config';
import { bytesToUInt64, getCurrentTimestamp, sleep } from './lib/utils';
import { solBlockTimeGet } from './lib/block';
import { confirmedConnection } from './lib/endpoint';
import { solCheckTr } from 'web3-sol-checker';

export let buyCountsInMintBlock: any = {}
export const buyingAssets: any = {}
export const tradingTokens: any = {}

function bytesToInt(bytes: number[]): number {
  return bytes[0] | (bytes[1] << 8) | (bytes[2] << 16) | (bytes[3] << 24);
}

export function getCumulative(token: string) {
  return tradingTokens[token]
}

export function IsExceedsCumulative(token: string) {
  if (!config.maxSolAmountBeforBuy || !tradingTokens[token])
    return false
  
  console.log(`[LOG] cumulative sol :`, tradingTokens[token])
  if (tradingTokens[token] > config.maxSolAmountBeforBuy) {
    console.log(`[LOG] cumulative sol exceeds :`, tradingTokens[token])
    return true
  }
  return false
}

async function getBuyCountInBlock(mintBlock: number, token: string): Promise<number> {
  let buyCount = 0
  let blockResp
  console.time('check-count')
  while (true) {
    try {
      blockResp = await confirmedConnection.getBlock(mintBlock, { maxSupportedTransactionVersion: 0 })
      break
    } catch (error) {
      await sleep(100)
    }
  }
  const transactions = blockResp?.transactions
  transactions?.forEach((tr: any) => {
    if (solTrIsPumpfunBuy(tr, token)) {
      console.log(`[LOG] pumpfun buy : sig = ${tr.transaction.signatures[0]}`)
      buyCount++
    }
  })
  console.timeEnd('check-count')
  if (buyCount) {
    buyCountsInMintBlock[token] = buyCount
  }
  return buyCount
}

export async function grpcLUTCallback(data: any, param: any) {
  if (data.filters.includes('transactionsSubKey') !== true)
    return
  const info = data.transaction
  if (info.transaction.meta.err)
    return

  const signature = bs58.encode(info.transaction.signature)
  const accounts = info.transaction.transaction.message.accountKeys.map((i: any) => bs58.encode(i))
  for (const item of [...info.transaction.transaction.message.instructions, ...info.transaction.meta.innerInstructions.map((i: any) => i.instructions).flat()]) {
    if (accounts[item.programIdIndex] !== LUT) continue
    const keyIndex = [...(item.accounts).values()]

    const idata = [...(item.data).values()]
    if (idata.length < 12)
      continue

    const lutExtendInstrAccounts = keyIndex.map((i: number) => accounts[i])
    // Extract the first 12 bytes
    const cmdType = bytesToInt(idata.slice(0, 4));
    const count = bytesToInt(idata.slice(4, 8));
    const subcmd = bytesToInt(idata.slice(8, 12));

    const addrBuffer = idata.slice(12)
    if (cmdType !== 2 && addrBuffer.length !== count * 32)
      continue
    const CHUNK_SIZE = 32
    const addresses = []
    for (let i = 0; i < count; i++) {
      const chunk = addrBuffer.slice(i * CHUNK_SIZE, i * CHUNK_SIZE + CHUNK_SIZE);
      const buffer = Buffer.from(chunk);
      addresses.push(bs58.encode(buffer));
    }

    const block = Number(info.slot)
    const lutSigner = lutExtendInstrAccounts[lutExtendInstrAccounts.length - 2]
    WhitelistAdd(lutSigner, addresses, block)
  }
}

export function grpcPFMintAuthCallback(data: any, param: any) {
  if (data.filters.includes('transactionsSubKey') !== true)
    return
  const info: any = data.transaction
  if (info.transaction.meta.err)
    return
  const signature = bs58.encode(info.transaction.signature)
  const accounts = info.transaction.transaction.message.accountKeys.map((i: any) => bs58.encode(i))
  let creator
  let token = ''
  let initialBuy = 0
  const mintBlock = Number(info.slot)
  const instructions = info.transaction.transaction.message.instructions
  const innerInstructions = info.transaction.meta.innerInstructions
  for (let i = 0; i < instructions.length; i++) {
    const item = instructions[i]
    const keyIndex = [...(item.accounts).values()]
    if (accounts[item.programIdIndex] !== PF_PROGRAM_ID.toBase58())
      continue
    if (keyIndex.length === 14) { // Mint Instruction
      creator = accounts[keyIndex[7]]
      // console.log(`[LOG] PumpFun token creation event:: (signature = ${signature} signer = ${creator})`)
      token = accounts[keyIndex[0]]
      // estimateDetectionTime(mintBlock)
    } else if (keyIndex.length === 12) {
      const devWallet = accounts[keyIndex[6]]
      const idata = [...(item.data).values()]
      const cmdType = bytesToUInt64(idata.slice(0, 8));
      const tokenAmount = Number(bytesToUInt64(idata.slice(8, 16))) / LAMPORTS_PER_SOL;
      if (cmdType !== BigInt("16927863322537952870"))
        continue

      if (tokenAmount) {
        const inners = innerInstructions.filter((inst: any) => inst.index === i)
        // console.log(`[LOG] SIG : ${signature}, i = ${i}`)
        for (const inn of inners) {
          const buyInstr = inn.instructions.find((instr: any) => accounts[instr.programIdIndex] === PF_PROGRAM_ID.toBase58())
          // console.log(JSON.stringify(buyInstr))
          if (buyInstr) {
            const bdata = [...(buyInstr.data).values()]
            const cmd = bytesToUInt64(bdata.slice(0, 8))
            const subcmd = bytesToUInt64(bdata.slice(8, 16))
            const bMint = bs58.encode(bdata.slice(16, 48))
            initialBuy = Number(bytesToUInt64(bdata.slice(48, 56))) / LAMPORTS_PER_SOL
            // console.log(`[LOG](MINT)(${token}) initialBuy = ${initialBuy}`)
            break
          }
        }
      }
    }
  }

  if (!creator || token === '')
    return
  reportDetectionTime(`${token}`, mintBlock)

  if (config.goodMakers.find((maker:string) => maker === creator)) {
    console.log(`[LOG](${token}) *********** Good Maker(${creator})'s token.`)
    buy(token, creator, mintBlock)
    return
  }

  if (WhitelistExist(creator) !== true) {
    // console.log(`[LOG](${token}) creator(${creator}) initialBuy(${initialBuy}) doesn't exist in whitelist skipping ...`)
    // pfGetTokenDataByApi(token)
    //   .then((meta) => console.log(`[LOG] token : `, meta))
    return
  }

  WhitelistRemove(creator)

  if (config.devBuyMin !== undefined && config.devBuyMax !== undefined) {
    if (initialBuy < config.devBuyMin || initialBuy > config.devBuyMax) {
      console.log(`[LOG](${token}) initial buy is not in range of permmited. (range: ${config.devBuyMin} - ${config.devBuyMax}, firstBuyAmount = ${initialBuy})`)
      return
    }
    if (config.initialBuyBlackList) {
      if (config.initialBuyBlackList.find((ib:number) => {
        const skipAmount = Number(ib.toFixed(2))
        initialBuy = Number(initialBuy.toFixed(2))
        return initialBuy == skipAmount
      })) {
        console.log(`[LOG](${token}) initial buy is in blacklist : ${initialBuy}`)
        return
      }
    }
  }

  console.log(`[LOG] ************* DETECT (TOKEN: ${token}, creator: ${creator})`)
  if (isCreateTokenExceeds(creator) === true
    && (!config.whitelist.find((wl:string) => wl === creator) || Math.random() < 0.7)) 
    return
  if (config.amountTrade) {
    // buyingTokenAdd(token, mintBlock)
    buy(token, creator, mintBlock)
    return
  }
}

async function estimateDetectionTime(slot: number) {
  const curTime = getCurrentTimestamp()
  const blockTime = await solBlockTimeGet(slot)
  if (blockTime)
    console.log(`[LOG] ::::::::: detection delay : ${curTime - blockTime} ms`)
}

// export function grpcPFProgramCallback(data: any, param: any) {
//   if (data.filters.includes('transactionsSubKey') !== true)
//     return
//   const info: any = data.transaction
//   if (info.transaction.meta.err)
//     return
//   const signature = bs58.encode(info.transaction.signature)
//   const slot = Number(info.slot)
//   const accounts = info.transaction.transaction.message.accountKeys.map((i: any) => bs58.encode(i))
//   for (const item of [...info.transaction.transaction.message.instructions, ...info.transaction.meta.innerInstructions.map((i: any) => i.instructions).flat()]) {
//     const keyIndex = [...(item.accounts).values()]
//     if (accounts[item.programIdIndex] !== PF_PROGRAM_ID.toBase58())
//       continue
//     if (keyIndex.length !== 12)
//       continue

//     const idata = [...(item.data).values()]
//     const cmdType = bytesToUInt64(idata.slice(0, 8));
//     if (cmdType !== PF_CMD_BUY)
//       continue
//     const token = accounts[keyIndex[2]]

//     if (!buyingAssets[slot]) {
//       buyingAssets[slot] = {};
//     }
//     if (!buyingAssets[slot][token]) {
//       buyingAssets[slot][token] = 0;
//     }
//     buyingAssets[slot][token]++
//     // console.log(`[DAVID](PF-Buy) slot: ${slot}, token: ${token}, SIG: ${signature}`)
//   }
//   delete buyingAssets[slot - 1000]
// }

export function grpcPFProgramCallback(data: any, params?: any) {
  if (data.filters.includes('transactionsSubKey') !== true)
    return
  const info: any = data.transaction
  if (info.transaction.meta.err)
    return
  const signature = bs58.encode(info.transaction.signature)
  const slot = Number(info.slot)
  const accounts = info.transaction.transaction.message.accountKeys.map((i: any) => bs58.encode(i))
  const instructions = info.transaction.transaction.message.instructions
  const innerInstructions = info.transaction.meta.innerInstructions
  for (let i = 0; i < instructions.length; i++) {
    const item = instructions[i]
    const keyIndex = [...(item.accounts).values()]
    const idata = [...(item.data).values()]
    let tokenAmount
    if (accounts[item.programIdIndex] === 'infwiWUCBtdDG61p285W5uaxC3VpvwP3Ww1KEbkLSx9') {
      const cmdType = bytesToUInt64(idata.slice(0, 8));
      if (keyIndex.length !== 14)
        continue
      tokenAmount = 1
    } else if (accounts[item.programIdIndex] === PF_PROGRAM_ID.toBase58()) {
      if (keyIndex.length !== 12)
        continue

      const cmdType = bytesToUInt64(idata.slice(0, 8));
      if (cmdType !== PF_CMD_BUY && cmdType !== PF_CMD_SELL) {
        console.log(`wrong cmd:: signature = ${signature}`)
        continue
      }
      tokenAmount = Number(bytesToUInt64(idata.slice(8, 16))) / LAMPORTS_PER_SOL;
    } else {
      continue
    }

    if (tokenAmount) {
      const inners = innerInstructions.filter((inst: any) => inst.index === i)
      // console.log(`[LOG] SIG : ${signature}, i = ${i}`)
      for (const inn of inners) {
        const buyInstr = inn.instructions.find((instr: any) => accounts[instr.programIdIndex] === PF_PROGRAM_ID.toBase58())
        // console.log(JSON.stringify(buyInstr))
        if (!buyInstr)
          continue
        const bdata = [...(buyInstr.data).values()]
        if (bdata.length >= 64) {
          const cmd = bytesToUInt64(bdata.slice(0, 8))
          const subcmd = bytesToUInt64(bdata.slice(8, 16))
          const bMint = bs58.encode(bdata.slice(16, 48))
          const solAmount = Number(bytesToUInt64(bdata.slice(48, 56))) / LAMPORTS_PER_SOL
          const tokenAmount = Number(bytesToUInt64(bdata.slice(56, 64))) / LAMPORTS_PER_SOL
          const isBuy = bdata.slice(64, 65)
          const token = accounts[keyIndex[2]]
          if (!isBuy)
            console.log(`[LOG](${token}) : ${isBuy ? 'buy' : 'sell'} : amount : ${solAmount}`)
          if (!tradingTokens[token])
            tradingTokens[token] = 0
          tradingTokens[token] += solAmount
          buyingTokenIncreaseBuyCount(token, slot)
          break
        }
      }
    }
  }
}