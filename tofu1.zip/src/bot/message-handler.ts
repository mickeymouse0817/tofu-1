import TelegramBot, { Message } from "node-telegram-bot-api";

export async function botMessageHandler(bot: TelegramBot, msg: Message): Promise<any> {

}