import { config } from "./config";
import dotenv from "dotenv"
import { solWalletImport } from "./lib/wallet";
import { pfGetTokenDataByApi, solPFBuy, solPFFetchPrice, solPFSell } from "./lib/3rdparty";
import { solTokenBalance, solTokenGetMeta } from "./lib/token";
import { getCurrentTimestamp, sleep } from "./lib/utils";
import { solBlockTimeGet } from "./lib/block";
import { solTrGetTimestamp } from "./lib/transaction";
import { buyingAssets, getCumulative, IsExceedsCumulative, tradingTokens } from "./detection";
import { buyingTokenFind, WhitelistRemove } from "./whitelist";
import path from "path";

dotenv.config()
const signer = solWalletImport(process.env.PRIVATE_KEY!)!

async function reportBlockNumber(txHash: string, startBlock: number) {
  const trTime = await solTrGetTimestamp(txHash)
  if (trTime) {
    console.log(`[LOG] :::::::::::::: bought after ${trTime.blockNumber - startBlock} blocks`)
  }
}

async function getTokenBalance(token: string): Promise<number> {
  while (true) {
    try {
      const [rawBalance, _] = await solTokenBalance(token, signer.publicKey)
      return Number(rawBalance)
    } catch (error) {
      await sleep(500)
    }
  }
}

/***************** BUY *********************/
// buy condition
// 1. check blacklist
export async function buy(token: string, creator: string, mintBlock?: number): Promise<void> {
  let retryCnt = 0
  let tx = ''
  let boutPrice = 0
  let cumulativeAmount = 0

  if (config.tickerBlacklist && config.tickerBlacklist.length) {
    let tokenMeta: any = undefined
    while (!tokenMeta) {
      tokenMeta = await pfGetTokenDataByApi(token)
      if (!tokenMeta) {
        await sleep(200)
        continue
      }
      console.log(`[LOG] token meta (name:${tokenMeta.name}, symbol: ${tokenMeta.symbol})`)
      if (config.tickerBlacklist.some((b: string) => tokenMeta.name?.includes(b) || tokenMeta.symbol?.includes(b))) {
        console.log(`[LOG](trade) Ticker(${tokenMeta.name} | ${tokenMeta.symbol}) is in blacklist! skip to buy ...`)
        return
      }
      if (!config.NumberAllow) {
        const containsNumbers = /\d/.test(tokenMeta.name) || /\d/.test(tokenMeta.symbol);
        if (containsNumbers) {
          console.log(`[LOG](trade) Tokens of which ticker | name contain number is not allowed ...`)
          return
        }
      }
    }
  }

  while ((tx === '' || tx === 'fetch error') && retryCnt < config.retryCount) {
    if (retryCnt) {
      // console.log(`[LOG](${token}) retry to buy ${retryCnt} times ...`)
      await sleep(200)
    }

    // if (IsExceedsCumulative(token)) {
    //   console.log(`[LOG](${token}) Bought amount exceeds limit, skip to buy ...`)
    //   return
    // }
    cumulativeAmount = getCumulative(token)
    tx = await solPFBuy(signer, token, config.amountTrade, config.slippage, config.prioityFee, config.jitoBuyTip, config)
    boutPrice = await solPFFetchPrice(token)
    if (tx === '') break
    retryCnt++
  }

  if (tx === 'fetch error' || tx === '') {
    console.log(`[LOG](${token}) Failed to buy! tx = ${tx}`)
    return
  }

  if (mintBlock)
    reportBlockNumber(tx, mintBlock)

  WhitelistRemove(creator)
  sell(token, tx, mintBlock, cumulativeAmount)
}

/***************** SELL *********************/
// sell condition
// 1. meet profit
// 2. timeout
// 3. stop loss

async function isNeedToSell(
  token: string,
  curPrice: number,
  boughtPrice: number,
  timeElapsed: number,
  mintBlock: number | undefined,
  cumulative: number | undefined,
  activityStart: number): Promise<boolean> {
  
  //   if (config.maxSolAmountBeforBuy && cumulative && cumulative > config.maxSolAmountBeforBuy) {
  //   console.log(`[LOG](trade) Cumulative sol exceeds(${cumulative}) selling instantly...`)
  //   return true
  // }
  const tp = (curPrice / boughtPrice) * 100
  if (tp >= (100 + config.tp)) {
    console.log(`[LOG](trade) Profit meet! (${tp - 100} %)`)
    return true
  }

  if (boughtPrice > curPrice) {
    if (tp < config.sl) {
      console.log(`[LOG](trade) Stop loss meet! (${tp} %)`)
      return true
    }
  }

  if (timeElapsed > config.profitTimeout) {
    console.log(`[LOG](trade) Time elapsed!`)
    return true
  }

  if (boughtPrice > 0.0001
    && (timeElapsed > 5/* || curPrice > boughtPrice*/)){
    console.log(`[LOG](trade) *** SELL *** Bought Price high & time elapsed!`)
    return true
  }

  if (config.maxBuyInSlot !== undefined
    && mintBlock
    && buyingAssets[mintBlock]
    && buyingAssets[mintBlock][token]
    && buyingAssets[mintBlock][token] > config.maxBuyInSlot) {
    console.log(`[LOG](trade) Buy count in mint block exceeds limit!`)
    return true
  }

  const noActivityTime = (getCurrentTimestamp() - activityStart) / 1000
  if (noActivityTime > config.activityTimeout) {
    console.log(`[LOG](trade) No activity!`)
    return true
  }

  return false
}
export async function sell(token: string, boughtTxHash: string, mintBlock?: number, cumulative?: number, _boughtPrice?: number): Promise<void> {
  let balance = 0
  let startTime = getCurrentTimestamp()
  let boughtPrice = _boughtPrice
  while(!boughtPrice) {
    boughtPrice = await solPFFetchPrice(token)
    await sleep(100)
  }
  // wait for buy completion
  while (!balance && (getCurrentTimestamp() - startTime) < 60000) {
    balance = await getTokenBalance(token)
  }

  if (!balance) {
    console.log(`[LOG] Buy failed!`)
    return
  }

  console.log(`[LOG] Bought! tx =`, boughtTxHash)
  startTime = getCurrentTimestamp()
  let activityStart = startTime
  let oldPrice = 0
  let cnt = 0
  while (balance) {
    await sleep(500)
    const curPrice = await solPFFetchPrice(token)
    if (!curPrice)
      continue
    
    if ((++cnt % 5 === 0) || curPrice != oldPrice) {
      const curTm = getCurrentTimestamp()
      if (curPrice != oldPrice)
        activityStart = curTm
      oldPrice = curPrice
      console.log(`[LOG](${token}) ------ (${curPrice}/${boughtPrice}) (passed: ${((curTm-startTime)/1000).toFixed(2)} s)`)
    }
    const timeElapsed = (getCurrentTimestamp() - startTime) / 1000
    if (await isNeedToSell(token, curPrice, boughtPrice, timeElapsed, mintBlock, cumulative, activityStart)) {
      const tx = await solPFSell(
        signer, 
        token, 
        balance, 
        config.slippage, 
        // curPrice > boughtPrice ? config.prioityFee : undefined, 
        1,
        curPrice > boughtPrice ? Math.max(config.jitoSellTip, 0.001) : 0.0005)
    }
    balance = await getTokenBalance(token)
  }

  console.log(`[LOG] Success to sell.`)
}
