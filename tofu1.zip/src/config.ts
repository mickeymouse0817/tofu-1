import { _100 } from "@raydium-io/raydium-sdk";
import { whitelist } from "./whitelist";

export const config = {
  amountTrade: 0.2,
  slippage: 100,
  cumulativeSol: 5,
  minLUTCount: 4,
  prioityFee: 7,
  retryCount: 20,
  jitoBuyTip: 0.003,
  jitoSellTip: 0.002,
  devBuyMin: 0,
  devBuyMax: 4,
  maxCreatedTokens: 0,
  maxBuyInSlot: 100,
  maxSolAmountBeforBuy: 8,
  // cumulativeBlacklist: [12, 13, 14],
  cumulativeBlacklist: [],
  // initialBuyBlackList: [1.54, 1.09, 0.5, 0.90, 1.44, 1.40, 2.08999, 1.25, 1.13, 1.45, 1.05, 1.08, 1.65, 1.74, 0.85, 1.93, 2.10, 1.94, 1.5, 1.84, 2.70, 2.30, 2.34, 1.8],
  // initialBuyBlackList: [0.95, 0.99, 0.80, 3],
  initialBuyBlackList: [],  
  maxTxCountInMintBlock: 1,
  tickerBlacklist: [],
  // tickerBlacklist: ['1dontbuy1' , 'dontbuy' ,  '123t3sging' , '1' , 'testing', 'T3sting', 'T3ST','TEN10', 't3sttt' , 'test', 't3ssst' , 'boobism' , 'Chaos'  ],
  // whitelist: ["DRoJmSmpbH4dh48aXL7fJWAettsKysstDvyxXF3GAmGF"],
  NumberAllow : true,
  tp: 15, // Take Profit (%)
  sl: 1, // Stop Loss (%)
  profitTimeout: 90, // seconds
  activityTimeout: 30,
  blacklist: [
    "4hi9Y7FQWPinV1Mpv7AAz2T19rGGRn3AGFzc211mV9HH",
    "EN9QAHoYzmqHzn5ZyWGMrdQdZkQLeCNajK2RRRi9bpZB",
    "9eXJMiwmk8K165d3LmFU1cJb8zqxR329VxFbScgDdwpB",
    "Ab3wwRseSE5f2QJkFy5wCFwb2e2UbytEVUVHujVapkUg",
    "4EygXeSXZoZys9Ptivd7hGzT3saBPYEqm62pXQxnTqt9",
    "B8M4grEuT7MHozjJfMmdV7FScmVXUXP5397b17NGFnuC",
    "33z4oJhnU88NUpf9Zi1mc4KA8RSqRGaBwfqdH794oVph",
    "BXVz46HyLxVzBezQvtR6i4NyVKWBShswyjMcANPTKY3c",
    "5KEGKQBUeeWQmZ9NxcwZ8P9r5vFnxpcpDcdgKAcKqZHS",
    "AJSoJSWbqtxQAxVe6qmuZpqWehRhLBErsJSAqNCKLzSA",
  ],
  whitelist: [
    "6MbD8LpEnCzDY9VTXLbUoz1gRY4KgjbWoJCoJVCKffto",
    "Cg8A7DM1B5RuxzkrcjZW3SDtDntUwVSKwoX6oPR4CkYE",
    "5rkYUupj95mHY1jqLao6caeeQ4f9vMeeFvJ36jCZyg7i",
    "7AiqaWb5gcpiKrcJCDRr5Z5h1o6BGDLukcGZR9zY7m1R",
    "HkczTJP1n9QkQEBYMi1J5aY2bZDkooo8SCT6PowkjjLm",
    "4Eju9Hptxq6F51AGmbFd474Uy2rVNrTcfUA9VUgkoAbf",
    "2RVdy5F7EXb6rx4FZpps9DmM5hAbuLb2YKHurj1Gec4r",
    "9dCinTyPXb8qSrMviviSwyDjWwzjxpo1NwHWFQ9w8wxM",
    
    "PfrJsXsxsyg7MdiWBW8eURHv4cH3vqV5SXb4nPoFuxp",
    "G97dfHgq7yMusphnsSosvoB9TYNQy4vr7bjXtaK3CfrQ",
    "4Z4udzUyuMLTXaxiKpkVyupyo1RYV9dELPjRCUVEh6aL"
    // ""
  ],
  goodMakers: [
    "FXX2JVBQx1THzmJRt26kDAhJDhLg7xZQksbtvhAKmqRC",
    "HR4XkgXq2guDEmSKGis8JDFa6KKhNLoL6vpQjp4DcFmk",
    "4gWjgfchEUNfV4k3XwjFR9V7zXUstccUUHCiQBytSTa5",
    "9i5a36DeheM9uSpbb2j2gBfqv9xTDmbVQgB6qz7EU1im",
    "J2seK1i1SazGQLApNFeyCUv8jDAFySpca61A71LN6hry",
    "C9es1HuZuwWN6Ri4MYUcyzMmtny8buXHnuNsD74NoUPu",
    "7KzbG7PaWMsDWUmE6q3bHFDPWrCv23SFQ6zPEBWk7WhB",

    "2R1SDLWpHb4YXahKWNa9wupN3KKwiDcP3vZmqKeGESgH",
    "2H2uhA6or2awUnGApfifJGsyT15m8za2gUBridXJYpXm",
    "DN4Do7FYAtgWGnAH8BoUD7s4bzwRAbrbk4GWN1eSUppU",
    "8Tq8jLfjHyCKk87AwtBRhFitzeHJjgkANJ5DD44f4iCN",
    "HV7utoLvzKWKP5anY3hQUYvMHFzTzqpZ1SNMbCDJLp3i",
    "FPELzTrRoYR94rsqhiXw9NP5fpGPBVmVR2JfdmwdWL2s",
    "HVgGXKzbKxJ6BAaDiP5cMkLmDCQovo6f2235zkycN9pd",
    "EGmukC1yhdEatE1JixMu5gBch449tWjQytwj9DX2fVwU",
    "7B4bNxMyRRw4DmxSMgBomNQ7yyeJpZqKaTyXBBhezi8b",
  ]
}